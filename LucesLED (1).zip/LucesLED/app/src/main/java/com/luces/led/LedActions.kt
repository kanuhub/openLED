package com.luces.led

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.Toast

/** Recibe los toques de los widgets. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val result = goAsync()
        LedActions.perform(
            ctx,
            intent.action ?: "",
            intent.getIntExtra("level", 100),
            intent.getIntExtra("color", Color.WHITE)
        ) { result.finish() }
    }
}

object LedActions {
    const val TOGGLE = "com.luces.led.TOGGLE"
    const val BRIGHT = "com.luces.led.BRIGHT"
    const val COLOR = "com.luces.led.COLOR"

    private var liveNeedsOn = false
    private var lastToast = 0L

    /**
     * Cambia el estado al instante (los widgets se redibujan con "Encendiendo…"),
     * vibra, envía la orden y confirma o revierte según el resultado.
     * onResult: true = ok, false = error, null = reemplazada por otra orden.
     */
    fun perform(ctx: Context, action: String, level: Int, color: Int, onResult: (Boolean?) -> Unit) {
        val mac = Store.mac(ctx)
        if (mac == null) {
            Toast.makeText(ctx, "Abre la app y elige tus luces primero", Toast.LENGTH_LONG).show()
            onResult(false)
            return
        }
        val prevOn = Store.isOn(ctx)
        val prevBright = Store.brightness(ctx)
        val prevColor = Store.color(ctx)
        val cmds = mutableListOf<ByteArray>()
        val label: String

        when (action) {
            TOGGLE -> {
                val turnOn = !prevOn
                cmds.add(if (turnOn) Led.ON else Led.OFF)
                label = if (turnOn) "Encendiendo…" else "Apagando…"
                Store.setOn(ctx, turnOn)
            }
            BRIGHT -> {
                if (!prevOn) cmds.add(Led.ON)
                cmds.add(Led.brightness(level))
                label = "Ajustando brillo…"
                Store.setBrightness(ctx, level)
                Store.setOn(ctx, true)
            }
            COLOR -> {
                if (!prevOn) cmds.add(Led.ON)
                cmds.add(Led.color(color))
                label = "Cambiando color…"
                Store.setColor(ctx, color)
                Store.setOn(ctx, true)
            }
            else -> {
                onResult(null)
                return
            }
        }

        Store.setBusy(ctx, label)
        WidgetViews.refreshAll(ctx)
        Haptics.tick(ctx)

        BleController.send(ctx, mac, cmds) { ok ->
            if (ok == null) {
                onResult(null)
                return@send
            }
            Store.setBusy(ctx, null)
            if (!ok) {
                Store.setOn(ctx, prevOn)
                Store.setBrightness(ctx, prevBright)
                Store.setColor(ctx, prevColor)
                Toast.makeText(ctx, "No se pudo conectar con las luces", Toast.LENGTH_SHORT).show()
                Haptics.error(ctx)
            }
            WidgetViews.refreshAll(ctx)
            onResult(ok)
        }
    }

    // ---------- cambio en vivo (al arrastrar el dedo) ----------

    /** Llamar al empezar a arrastrar. Si la tira estaba apagada, el primer envío la enciende. */
    fun beginLive(ctx: Context) {
        liveNeedsOn = !Store.isOn(ctx)
    }

    /**
     * Envía el valor actual sin esperar ni redibujar widgets. Si llegan muchos seguidos,
     * el controlador Bluetooth solo conserva el último, así la tira sigue al dedo.
     */
    fun live(ctx: Context, action: String, level: Int, color: Int) {
        val mac = Store.mac(ctx)
        if (mac == null) {
            toastOnce(ctx, "Elige tus luces primero")
            return
        }
        val cmds = mutableListOf<ByteArray>()
        val withOn = liveNeedsOn
        if (withOn) cmds.add(Led.ON)
        when (action) {
            BRIGHT -> {
                cmds.add(Led.brightness(level))
                Store.setBrightness(ctx, level)
            }
            COLOR -> {
                cmds.add(Led.color(color))
                Store.setColor(ctx, color)
            }
            else -> return
        }
        Store.setOn(ctx, true)
        BleController.send(ctx, mac, cmds) { ok ->
            if (ok == true && withOn) liveNeedsOn = false
            if (ok == false) toastOnce(ctx, "No se pudo conectar con las luces")
        }
    }

    /** Llamar al soltar el dedo: refresca los widgets con el valor final. */
    fun endLive(ctx: Context) {
        WidgetViews.refreshAll(ctx)
    }

    private fun toastOnce(ctx: Context, msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastToast < 3000) return
        lastToast = now
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }
}
