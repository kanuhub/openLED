package com.luces.led

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/** Deslizador con el estilo del tema. onChange(porcentaje 1-100, soltado) se llama mientras arrastras. */
class LiveSlider(ctx: Context, private val look: Look) : View(ctx) {
    var onChange: ((Int, Boolean) -> Unit)? = null
    var onDown: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private var cache: Bitmap? = null
    private var percent = 100

    fun setPercent(p: Int) {
        val v = p.coerceIn(1, 100)
        if (v == percent && cache != null) return
        percent = v
        cache = null
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cache = null
    }

    override fun onDraw(canvas: Canvas) {
        if (width <= 0 || height <= 0) return
        var b = cache
        if (b == null || b.width != width || b.height != height) {
            b = Skin.sliderBar(width, height, percent / 100f, look, density)
            cache = b
        }
        canvas.drawBitmap(b, 0f, 0f, null)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (e.actionMasked == MotionEvent.ACTION_DOWN) onDown?.invoke()
                val kr = height * 0.42f
                val frac = ((e.x - kr) / (width - 2f * kr)).coerceIn(0f, 1f)
                val p = (frac * 100f).roundToInt().coerceIn(1, 100)
                if (p != percent) {
                    percent = p
                    cache = null
                    invalidate()
                    performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                }
                onChange?.invoke(percent, e.actionMasked == MotionEvent.ACTION_UP)
            }
        }
        return true
    }
}
