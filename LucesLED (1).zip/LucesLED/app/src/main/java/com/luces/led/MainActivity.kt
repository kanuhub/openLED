package com.luces.led

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private lateinit var orb: PowerOrb
    private lateinit var statusTxt: TextView
    private lateinit var deviceTxt: TextView
    private lateinit var brightTxt: TextView
    private lateinit var seek: SeekBar
    private lateinit var preview: View
    private lateinit var hexInput: EditText
    private lateinit var wheel: ColorWheelView
    private lateinit var savedBox: LinearLayout
    private lateinit var snackView: TextView
    private lateinit var pageControl: ScrollView
    private lateinit var pageThemes: ScrollView
    private lateinit var tabControl: Button
    private lateinit var tabThemes: Button
    private var controlCards: List<View> = emptyList()
    private var themesShown = false
    private var currentColor = 0xFFFFFFFF.toInt()
    private var seeking = false
    private var settingHex = false

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        c.background = Ui.rounded(this, Ui.CARD, 22)
        c.layoutParams = Ui.lp(this, top = 14)
        return c
    }

    private fun circle(color: Int, size: Int): View {
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        g.setStroke(dp(1), 0x33FFFFFF)
        v.background = g
        val p = LinearLayout.LayoutParams(dp(size), dp(size))
        p.setMargins(dp(3), dp(3), dp(3), dp(3))
        v.layoutParams = p
        return v
    }

    // ---------- pantalla ----------
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        currentColor = Store.color(this)

        val rootFrame = FrameLayout(this)
        rootFrame.setBackgroundColor(Ui.BG)

        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20), dp(40), dp(20), dp(8))
        header.addView(Ui.label(this, "Luces LED", 30f, Ui.TEXT, true))
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabControl = Ui.pill(this, "Control", true) { showTab(0) }
        tabThemes = Ui.pill(this, "Temas", false) { showTab(1) }
        tabs.addView(tabControl, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(6) })
        tabs.addView(tabThemes, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { leftMargin = dp(6) })
        header.addView(tabs, Ui.lp(this, top = 10))
        main.addView(header)

        val pages = FrameLayout(this)
        pageControl = ScrollView(this)
        pageControl.isFillViewport = true
        pageControl.addView(buildControl())
        pageThemes = ScrollView(this)
        pageThemes.isFillViewport = true
        pageThemes.visibility = View.GONE
        pageThemes.addView(ThemesPage(this).build())
        pages.addView(pageControl, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        pages.addView(pageThemes, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        main.addView(pages, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        rootFrame.addView(main, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

        snackView = Ui.label(this, "", 14f, 0xFF111111.toInt(), true)
        snackView.setPadding(dp(18), dp(12), dp(18), dp(12))
        snackView.background = Ui.rounded(this, Ui.ACCENT, 24)
        snackView.visibility = View.GONE
        val sp = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        sp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        sp.bottomMargin = dp(36)
        rootFrame.addView(snackView, sp)

        setContentView(rootFrame)

        refreshDevice()
        refreshSaved()
        syncUi()
        requestPerms()
        rootFrame.post { Ui.enter(controlCards) }
    }

    override fun onResume() {
        super.onResume()
        syncUi()
        val mac = Store.mac(this)
        if (mac != null && hasPerms()) BleController.warmUp(this, mac)
    }

    private fun buildControl(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(4), dp(16), dp(32))
        val cards = mutableListOf<View>()

        // Encendido
        val hero = card()
        hero.gravity = Gravity.CENTER_HORIZONTAL
        orb = PowerOrb(this)
        orb.setOnClickListener { toggle() }
        Ui.press(orb, 0.92f)
        hero.addView(orb, LinearLayout.LayoutParams(Ui.MATCH, dp(190)))
        statusTxt = Ui.label(this, "", 20f, Ui.TEXT, true)
        statusTxt.gravity = Gravity.CENTER
        hero.addView(statusTxt, Ui.lp(this))
        deviceTxt = Ui.label(this, "", 13f, Ui.SUB)
        deviceTxt.gravity = Gravity.CENTER
        hero.addView(deviceTxt, Ui.lp(this, top = 2))
        hero.addView(Ui.pill(this, "Buscar / cambiar luces", false) { scanDialog() }, Ui.lp(this, top = 12))
        col.addView(hero)
        cards.add(hero)

        // Brillo (cambia en vivo mientras arrastras)
        val c2 = card()
        c2.addView(Ui.label(this, "Brillo", 16f, Ui.TEXT, true))
        brightTxt = Ui.label(this, "", 14f, Ui.SUB)
        c2.addView(brightTxt, Ui.lp(this, top = 2))
        seek = SeekBar(this)
        seek.max = 100
        seek.progress = Store.brightness(this)
        seek.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        seek.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        brightTxt.text = "${maxOf(seek.progress, 1)}%"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                brightTxt.text = "${maxOf(p, 1)}%"
                if (fromUser) LedActions.live(this@MainActivity, LedActions.BRIGHT, maxOf(p, 1), 0)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {
                seeking = true
                LedActions.beginLive(this@MainActivity)
            }
            override fun onStopTrackingTouch(sb: SeekBar) {
                seeking = false
                LedActions.live(this@MainActivity, LedActions.BRIGHT, maxOf(sb.progress, 1), 0)
                LedActions.endLive(this@MainActivity)
                syncUi()
            }
        })
        c2.addView(seek, Ui.lp(this, top = 6))
        col.addView(c2)
        cards.add(c2)

        // Color (cambia en vivo mientras deslizas por la rueda)
        val c3 = card()
        c3.addView(Ui.label(this, "Color", 16f, Ui.TEXT, true))
        wheel = ColorWheelView(this)
        wheel.setColor(currentColor)
        wheel.onDown = { LedActions.beginLive(this) }
        wheel.onPick = { c, released ->
            currentColor = c
            updatePreview()
            LedActions.live(this, LedActions.COLOR, 0, c)
            if (released) {
                LedActions.endLive(this)
                syncUi()
            }
        }
        c3.addView(wheel, Ui.lp(this, h = dp(250), top = 8))

        // Código HEX
        val info = LinearLayout(this)
        info.orientation = LinearLayout.HORIZONTAL
        info.gravity = Gravity.CENTER_VERTICAL
        preview = View(this)
        info.addView(preview, LinearLayout.LayoutParams(dp(36), dp(36)))
        hexInput = buildHexInput()
        info.addView(hexInput, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
            leftMargin = dp(12)
            rightMargin = dp(8)
        })
        info.addView(Ui.pill(this, "Aplicar", false) { applyHex(true) }, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP))
        c3.addView(info, Ui.lp(this, top = 8))
        c3.addView(Ui.pill(this, "Guardar color", true) { saveDialog() }, Ui.lp(this, top = 8))
        updatePreview()

        c3.addView(Ui.label(this, "Colores rápidos", 13f, Ui.SUB), Ui.lp(this, top = 14))
        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        presets.gravity = Gravity.CENTER
        for (i in Palette.COLORS.indices) {
            val c = Palette.COLORS[i]
            val v = circle(c, 28)
            v.setOnClickListener {
                currentColor = c
                wheel.setColor(c)
                updatePreview()
                applyColor(c)
            }
            Ui.press(v, 0.8f)
            presets.addView(v)
        }
        c3.addView(presets, Ui.lp(this, top = 6))
        col.addView(c3)
        cards.add(c3)

        // Mis colores
        val c4 = card()
        c4.addView(Ui.label(this, "Mis colores", 16f, Ui.TEXT, true))
        c4.addView(
            Ui.label(this, "Toca ★ para mostrar el color en los widgets de colores (máx. 6).", 13f, Ui.SUB),
            Ui.lp(this, top = 4)
        )
        savedBox = LinearLayout(this)
        savedBox.orientation = LinearLayout.VERTICAL
        c4.addView(savedBox, Ui.lp(this, top = 6))
        col.addView(c4)
        cards.add(c4)

        controlCards = cards
        return col
    }

    // ---------- código HEX ----------
    private fun buildHexInput(): EditText {
        val e = EditText(this)
        e.setTextColor(Ui.TEXT)
        e.setHintTextColor(Ui.SUB)
        e.hint = "#RRGGBB"
        e.typeface = Typeface.MONOSPACE
        e.textSize = 16f
        e.setSingleLine()
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        e.imeOptions = EditorInfo.IME_ACTION_DONE
        e.background = Ui.rounded(this, Ui.CARD2, 14)
        e.setPadding(dp(14), 0, dp(14), 0)
        val onlyHex = InputFilter { src, _, _, _, _, _ ->
            if (src.all { it == '#' || it.isDigit() || it.lowercaseChar() in 'a'..'f' }) null else ""
        }
        e.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(7), onlyHex)
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!settingHex) applyHex(false)
            }
        })
        e.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard(v)
                true
            } else {
                false
            }
        }
        return e
    }

    private fun applyHex(explicit: Boolean) {
        val t = hexInput.text.toString().trim().removePrefix("#")
        if (t.length != 6) {
            if (explicit) snack("Escribe 6 dígitos HEX, por ejemplo #FF8800")
            return
        }
        val v = t.toLongOrNull(16)
        if (v == null) {
            if (explicit) snack("Código no válido")
            return
        }
        val c = (0xFF000000L or v).toInt()
        currentColor = c
        wheel.setColor(c)
        paintPreview()
        applyColor(c)
        if (explicit) hideKeyboard(hexInput)
    }

    private fun hideKeyboard(v: View) {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    // ---------- pestañas ----------
    private fun showTab(i: Int) {
        Ui.stylePill(this, tabControl, i == 0)
        Ui.stylePill(this, tabThemes, i == 1)
        val show = if (i == 0) pageControl else pageThemes
        val hide = if (i == 0) pageThemes else pageControl
        if (show.visibility == View.VISIBLE && hide.visibility == View.GONE) return
        show.animate().cancel()
        hide.animate().cancel()
        show.visibility = View.VISIBLE
        show.alpha = 0f
        show.translationX = (if (i == 1) 1 else -1) * dp(36).toFloat()
        show.animate().alpha(1f).translationX(0f).setStartDelay(0).setDuration(340)
            .setInterpolator(DecelerateInterpolator(1.7f)).start()
        hide.animate().alpha(0f).setStartDelay(0).setDuration(160)
            .withEndAction { hide.visibility = View.GONE }.start()
        if (i == 1 && !themesShown) {
            themesShown = true
            val col = pageThemes.getChildAt(0) as LinearLayout
            val kids = (0 until col.childCount).map { col.getChildAt(it) }
            pageThemes.post { Ui.enter(kids) }
        }
    }

    fun snack(msg: String) {
        snackView.animate().cancel()
        snackView.text = msg
        snackView.visibility = View.VISIBLE
        snackView.alpha = 0f
        snackView.translationY = dp(60).toFloat()
        snackView.animate().alpha(1f).translationY(0f).setStartDelay(0).setDuration(320)
            .setInterpolator(OvershootInterpolator(1.4f))
            .withEndAction {
                snackView.animate().alpha(0f).setStartDelay(1700).setDuration(300)
                    .withEndAction { snackView.visibility = View.GONE }.start()
            }.start()
    }

    // ---------- estado ----------
    private fun refreshDevice() {
        val mac = Store.mac(this)
        deviceTxt.text = if (mac == null) "Sin luces seleccionadas"
        else "${Store.deviceName(this) ?: "Luces"} · $mac"
    }

    private fun syncUi() {
        val on = Store.isOn(this)
        val busy = Store.busyText(this)
        orb.setOn(on)
        orb.setBusy(busy != null)
        statusTxt.text = busy ?: if (on) "Encendidas" else "Apagadas"
        if (!seeking) {
            seek.progress = Store.brightness(this)
            brightTxt.text = "${maxOf(seek.progress, 1)}%"
        }
    }

    private fun paintPreview() {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(currentColor)
        g.setStroke(dp(2), 0x55FFFFFF)
        preview.background = g
    }

    private fun updatePreview() {
        paintPreview()
        val txt = String.format("#%06X", currentColor and 0xFFFFFF)
        if (hexInput.text.toString() != txt) {
            settingHex = true
            hexInput.setText(txt)
            settingHex = false
        }
    }

    // ---------- órdenes ----------
    private fun dispatchAction(action: String, level: Int, color: Int) {
        LedActions.perform(this, action, level, color) { ok ->
            if (ok != null) syncUi()
        }
        syncUi()
    }

    private fun toggle() = dispatchAction(LedActions.TOGGLE, 0, 0)
    private fun applyColor(c: Int) = dispatchAction(LedActions.COLOR, 0, c)

    // ---------- colores guardados ----------
    private fun saveDialog() {
        val input = EditText(this)
        input.hint = "Nombre (opcional)"
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Guardar color")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val l = Store.saved(this)
                val hex = String.format("#%06X", currentColor and 0xFFFFFF)
                val nm = input.text.toString().trim().ifEmpty { hex }
                l.add(Store.Saved(currentColor, nm, l.count { it.pinned } < 6))
                Store.setSaved(this, l)
                refreshSaved()
                snack("Color guardado")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun refreshSaved() {
        savedBox.removeAllViews()
        val list = Store.saved(this)
        if (list.isEmpty()) {
            savedBox.addView(Ui.label(this, "Aún no tienes colores guardados.", 13f, Ui.SUB))
        }
        list.forEachIndexed { i, s ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(4), 0, dp(4))
            row.addView(circle(s.color, 30))

            val name = Ui.label(this, s.name + "\n" + String.format("#%06X", s.color and 0xFFFFFF), 14f, Ui.TEXT)
            name.setOnClickListener {
                currentColor = s.color
                wheel.setColor(s.color)
                updatePreview()
                applyColor(s.color)
            }
            row.addView(name, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { leftMargin = dp(8) })

            val star = Ui.label(this, if (s.pinned) "★" else "☆", 24f, if (s.pinned) Ui.ACCENT else Ui.SUB)
            star.setPadding(dp(10), dp(6), dp(10), dp(6))
            star.setOnClickListener {
                val l = Store.saved(this)
                if (!s.pinned && l.count { it.pinned } >= 6) {
                    snack("Máximo 6 colores en el widget")
                    return@setOnClickListener
                }
                if (i < l.size) l[i] = Store.Saved(s.color, s.name, !s.pinned)
                Store.setSaved(this, l)
                refreshSaved()
                Haptics.tick(this)
            }
            Ui.press(star, 0.7f)
            row.addView(star)

            val del = Ui.label(this, "✕", 18f, Ui.SUB)
            del.setPadding(dp(10), dp(6), dp(6), dp(6))
            del.setOnClickListener {
                val l = Store.saved(this)
                if (i < l.size) l.removeAt(i)
                Store.setSaved(this, l)
                refreshSaved()
            }
            Ui.press(del, 0.7f)
            row.addView(del)
            savedBox.addView(row)
        }
        WidgetViews.refreshAll(this)
    }

    // ---------- búsqueda de luces ----------
    private fun scanDialog() {
        if (!hasPerms()) { requestPerms(); return }
        val scanner = getSystemService(BluetoothManager::class.java).adapter?.bluetoothLeScanner
        if (scanner == null) { snack("Activa el Bluetooth"); return }

        val found = LinkedHashMap<String, String>()
        val ad = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        val cb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                val n = r.device.name ?: return
                if (found.put(r.device.address, n) == null) ad.add("$n  (${r.device.address})")
            }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Buscando luces… (cierra LotusLamp)")
            .setAdapter(ad) { _, i ->
                val mac = found.keys.elementAt(i)
                Store.setDevice(this, mac, found[mac] ?: "Luces")
                refreshDevice()
                BleController.warmUp(this, mac)
            }
            .setNegativeButton("Cerrar", null)
            .create()
        dlg.setOnDismissListener { try { scanner.stopScan(cb) } catch (_: Exception) {} }
        dlg.show()
        scanner.startScan(cb)
    }

    private fun perms() =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasPerms() = perms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    private fun requestPerms() { if (!hasPerms()) requestPermissions(perms(), 1) }
}
