package com.luces.led

import android.app.Activity
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Ventana flotante que se abre desde los widgets "Brillo fino" y "Círculo de color".
 * Tiene un deslizador (o la rueda) real y la tira cambia en vivo mientras arrastras.
 * Se cierra tocando fuera de la tarjeta.
 */
class PanelActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setBackgroundDrawable(ColorDrawable(0x73000000))

        val colorMode = intent.getStringExtra("mode") == "color"
        val look = Store.cfg(this, if (colorMode) WKey.WHEEL else WKey.FINE).look()
        val dens = resources.displayMetrics.density
        fun dp(v: Int) = (v * dens).toInt()
        val tf = if (look.mono) Typeface.MONOSPACE else Typeface.DEFAULT

        fun text(t: String, size: Float, color: Int, bold: Boolean): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.textSize = size
            tv.setTextColor(color)
            tv.setTypeface(tf, if (bold) Typeface.BOLD else Typeface.NORMAL)
            return tv
        }

        val cardW = minOf(resources.displayMetrics.widthPixels - dp(40), dp(340))
        val cardH = if (colorMode) dp(430) else dp(170)

        val root = FrameLayout(this)
        root.setOnClickListener { finish() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(22), dp(20), dp(22), dp(20))
        card.background = BitmapDrawable(resources, Skin.card(cardW, cardH, look, dens))
        card.setOnClickListener { }
        val cp = FrameLayout.LayoutParams(cardW, cardH)
        cp.gravity = Gravity.CENTER
        root.addView(card, cp)

        if (!colorMode) {
            card.addView(text("Brillo", 18f, look.text, true))
            val valueTxt = text(Store.brightness(this).toString() + "%", 14f, look.sub, false)
            card.addView(valueTxt)
            val slider = LiveSlider(this, look)
            slider.setPercent(Store.brightness(this))
            slider.onDown = { LedActions.beginLive(this) }
            slider.onChange = { p, released ->
                valueTxt.text = p.toString() + "%"
                LedActions.live(this, LedActions.BRIGHT, p, 0)
                if (released) LedActions.endLive(this)
            }
            val sp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64))
            sp.topMargin = dp(14)
            card.addView(slider, sp)
        } else {
            card.addView(text("Color", 18f, look.text, true))
            val wheel = ColorWheelView(this)
            wheel.setColor(Store.color(this))
            val wp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(280))
            wp.topMargin = dp(6)
            card.addView(wheel, wp)

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val swatch = View(this)
            val hex = text("", 16f, look.text, true)
            fun paint(c: Int) {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(c)
                g.setStroke(dp(2), 0x66FFFFFF)
                swatch.background = g
                hex.text = String.format("#%06X", c and 0xFFFFFF)
            }
            paint(Store.color(this))
            row.addView(swatch, LinearLayout.LayoutParams(dp(34), dp(34)))
            val hp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            hp.leftMargin = dp(12)
            row.addView(hex, hp)
            val rp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            rp.topMargin = dp(8)
            card.addView(row, rp)

            wheel.onDown = { LedActions.beginLive(this) }
            wheel.onPick = { c, released ->
                paint(c)
                LedActions.live(this, LedActions.COLOR, 0, c)
                if (released) LedActions.endLive(this)
            }
        }

        setContentView(root)
        card.alpha = 0f
        card.scaleX = 0.88f
        card.scaleY = 0.88f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380)
            .setInterpolator(OvershootInterpolator(1.6f)).start()

        val mac = Store.mac(this)
        if (mac != null) BleController.warmUp(this, mac)
    }

    override fun onDestroy() {
        LedActions.endLive(this)
        super.onDestroy()
    }
}
