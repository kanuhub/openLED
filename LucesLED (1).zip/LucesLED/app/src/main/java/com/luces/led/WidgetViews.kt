package com.luces.led

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.RemoteViews
import kotlin.math.max
import kotlin.math.min

abstract class BaseWidget : AppWidgetProvider() {
    abstract fun build(ctx: Context, mgr: AppWidgetManager, id: Int): RemoteViews

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx, mgr, id))
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        mgr.updateAppWidget(id, build(ctx, mgr, id))
    }
}

class SwitchWidget : BaseWidget() {
    override fun build(ctx: Context, mgr: AppWidgetManager, id: Int) = WidgetViews.switchFor(ctx, mgr, id)
}

class PowerWidget : BaseWidget() {
    override fun build(ctx: Context, mgr: AppWidgetManager, id: Int) = WidgetViews.powerFor(ctx, mgr, id)
}

class BrightnessWidget : BaseWidget() {
    override fun build(ctx: Context, mgr: AppWidgetManager, id: Int) = WidgetViews.brightnessFor(ctx, mgr, id)
}

class ColorWidget : BaseWidget() {
    override fun build(ctx: Context, mgr: AppWidgetManager, id: Int) = WidgetViews.colorFor(ctx, mgr, id)
}

class FineBrightWidget : BaseWidget() {
    override fun build(ctx: Context, mgr: AppWidgetManager, id: Int) = WidgetViews.fineFor(ctx, mgr, id)
}

class WheelWidget : BaseWidget() {
    override fun build(ctx: Context, mgr: AppWidgetManager, id: Int) = WidgetViews.wheelFor(ctx, mgr, id)
}

object WidgetViews {
    private val LEVELS = intArrayOf(20, 40, 60, 80, 100)

    /** Escala de las imágenes generadas (limitada para no gastar memoria). */
    fun scale(ctx: Context): Float = min(ctx.resources.displayMetrics.density, 2f)

    private fun sizeOf(mgr: AppWidgetManager, id: Int, defW: Int, defH: Int): IntArray {
        val o = mgr.getAppWidgetOptions(id)
        val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        return intArrayOf(if (w > 0) w else defW, if (h > 0) h else defH)
    }

    fun switchFor(ctx: Context, mgr: AppWidgetManager, id: Int): RemoteViews {
        val sz = sizeOf(mgr, id, 250, 72)
        return switchView(ctx, sz[0], sz[1], false)
    }

    fun powerFor(ctx: Context, mgr: AppWidgetManager, id: Int): RemoteViews {
        val sz = sizeOf(mgr, id, 64, 64)
        return powerView(ctx, sz[0], sz[1], false)
    }

    fun brightnessFor(ctx: Context, mgr: AppWidgetManager, id: Int): RemoteViews {
        val sz = sizeOf(mgr, id, 280, 76)
        return brightnessView(ctx, sz[0], sz[1], false)
    }

    fun colorFor(ctx: Context, mgr: AppWidgetManager, id: Int): RemoteViews {
        val sz = sizeOf(mgr, id, 280, 120)
        return colorView(ctx, sz[0], sz[1], false)
    }

    fun action(ctx: Context, action: String, level: Int = 0, color: Int = 0): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java).setAction(action)
            .setData(Uri.parse("led://$action/$level/$color"))
            .putExtra("level", level)
            .putExtra("color", color)
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun openApp(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

    // preview = true: sin acciones al tocar (se usa para mostrar la vista previa dentro de la app)

    fun switchView(ctx: Context, wDp: Int, hDp: Int, preview: Boolean): RemoteViews {
        val look = Store.cfg(ctx, WKey.SWITCH).look()
        val s = scale(ctx)
        val on = Store.isOn(ctx)
        val busy = if (preview) null else Store.busyText(ctx)
        val v = RemoteViews(ctx.packageName, R.layout.widget_switch)
        v.setImageViewBitmap(R.id.sw_bg, Skin.card((wDp * s).toInt(), (hDp * s).toInt(), look, s))
        v.setImageViewBitmap(R.id.sw_track, Skin.switchTrack((56 * s).toInt(), (32 * s).toInt(), on, look, s))
        v.setTextViewText(R.id.sw_state, busy ?: if (on) "Encendidas" else "Apagadas")
        v.setTextColor(R.id.sw_title, look.text)
        v.setTextColor(R.id.sw_state, if (busy != null) look.accent else look.sub)
        v.setInt(R.id.sw_icon, "setColorFilter", if (on) look.accent else look.sub)
        val alpha = if (busy != null) 150 else 255
        v.setInt(R.id.sw_track, "setImageAlpha", alpha)
        v.setInt(R.id.sw_icon, "setImageAlpha", alpha)
        if (!preview) v.setOnClickPendingIntent(R.id.sw_root, action(ctx, LedActions.TOGGLE))
        return v
    }

    fun powerView(ctx: Context, wDp: Int, hDp: Int, preview: Boolean): RemoteViews {
        val look = Store.cfg(ctx, WKey.POWER).look()
        val s = scale(ctx)
        val on = Store.isOn(ctx)
        val busy = if (preview) null else Store.busyText(ctx)
        val v = RemoteViews(ctx.packageName, R.layout.widget_power)
        val size = (min(wDp, hDp) * s).toInt()
        v.setImageViewBitmap(R.id.pw_btn, Skin.powerButton(size, on, look, s))
        v.setInt(R.id.pw_btn, "setImageAlpha", if (busy != null) 150 else 255)
        if (!preview) v.setOnClickPendingIntent(R.id.pw_btn, action(ctx, LedActions.TOGGLE))
        return v
    }

    fun brightnessView(ctx: Context, wDp: Int, hDp: Int, preview: Boolean): RemoteViews {
        val look = Store.cfg(ctx, WKey.BRIGHT).look()
        val s = scale(ctx)
        val cur = Store.brightness(ctx)
        val on = Store.isOn(ctx)
        val busy = if (preview) null else Store.busyText(ctx)
        val v = RemoteViews(ctx.packageName, R.layout.widget_brightness)
        v.setImageViewBitmap(R.id.br_bg, Skin.card((wDp * s).toInt(), (hDp * s).toInt(), look, s))
        v.setTextViewText(R.id.br_title, busy ?: if (on) "Brillo · $cur%" else "Brillo · apagado")
        v.setTextColor(R.id.br_title, if (busy != null) look.accent else look.text)
        val segW = ((wDp - 20 - 30) / 5f).coerceAtLeast(16f)
        val segH = (hDp - 20 - 20 - 6f).coerceAtLeast(16f)
        val ids = intArrayOf(R.id.br_1, R.id.br_2, R.id.br_3, R.id.br_4, R.id.br_5)
        for (i in ids.indices) {
            val lit = on && LEVELS[i] <= cur
            v.setImageViewBitmap(
                ids[i],
                Skin.segment((segW * s).toInt(), (segH * s).toInt(), LEVELS[i].toString(), lit, look, s)
            )
            v.setInt(ids[i], "setImageAlpha", if (busy != null) 165 else 255)
            if (!preview) v.setOnClickPendingIntent(ids[i], action(ctx, LedActions.BRIGHT, LEVELS[i], 0))
        }
        return v
    }

    fun colorView(ctx: Context, wDp: Int, hDp: Int, preview: Boolean): RemoteViews {
        val look = Store.cfg(ctx, WKey.COLORS).look()
        val s = scale(ctx)
        val on = Store.isOn(ctx)
        val curColor = Store.color(ctx) and 0xFFFFFF
        val busy = if (preview) null else Store.busyText(ctx)
        val v = RemoteViews(ctx.packageName, R.layout.widget_colors)
        v.setImageViewBitmap(R.id.cl_bg, Skin.card((wDp * s).toInt(), (hDp * s).toInt(), look, s))
        val dotPx = (36 * s).toInt()
        val alpha = if (busy != null) 180 else 255

        val presetIds = intArrayOf(R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5, R.id.c6, R.id.c7, R.id.c8)
        for (i in presetIds.indices) {
            val c = Palette.COLORS[i]
            val sel = on && (c and 0xFFFFFF) == curColor
            v.setImageViewBitmap(presetIds[i], Skin.dot(dotPx, c, sel, false, look, s))
            v.setInt(presetIds[i], "setImageAlpha", alpha)
            if (!preview) v.setOnClickPendingIntent(presetIds[i], action(ctx, LedActions.COLOR, 0, c))
        }

        val savedIds = intArrayOf(R.id.s1, R.id.s2, R.id.s3, R.id.s4, R.id.s5, R.id.s6)
        val pinned = Store.saved(ctx).filter { it.pinned }.take(6)
        for (i in savedIds.indices) {
            if (i < pinned.size) {
                val c = pinned[i].color
                val sel = on && (c and 0xFFFFFF) == curColor
                v.setImageViewBitmap(savedIds[i], Skin.dot(dotPx, c, sel, false, look, s))
                v.setInt(savedIds[i], "setImageAlpha", alpha)
                if (!preview) v.setOnClickPendingIntent(savedIds[i], action(ctx, LedActions.COLOR, 0, c))
            } else {
                v.setImageViewBitmap(savedIds[i], Skin.dot(dotPx, 0, false, true, look, s))
                if (!preview) v.setOnClickPendingIntent(savedIds[i], openApp(ctx))
            }
        }
        return v
    }

    fun fineFor(ctx: Context, mgr: AppWidgetManager, id: Int): RemoteViews {
        val sz = sizeOf(mgr, id, 280, 76)
        return fineView(ctx, sz[0], sz[1], false)
    }

    fun wheelFor(ctx: Context, mgr: AppWidgetManager, id: Int): RemoteViews {
        val sz = sizeOf(mgr, id, 280, 130)
        return wheelView(ctx, sz[0], sz[1], false)
    }

    private fun openPanel(ctx: Context, mode: String): PendingIntent {
        val i = Intent(ctx, PanelActivity::class.java)
            .putExtra("mode", mode)
            .setData(Uri.parse("led://panel/$mode"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Brillo fino: barra de 20 pasos (cada 5 %) y botón que abre la ventana flotante con deslizador. */
    fun fineView(ctx: Context, wDp: Int, hDp: Int, preview: Boolean): RemoteViews {
        val look = Store.cfg(ctx, WKey.FINE).look()
        val s = scale(ctx)
        val cur = Store.brightness(ctx)
        val on = Store.isOn(ctx)
        val busy = if (preview) null else Store.busyText(ctx)
        val v = RemoteViews(ctx.packageName, R.layout.widget_fine)
        v.setImageViewBitmap(R.id.fb_bg, Skin.card((wDp * s).toInt(), (hDp * s).toInt(), look, s))
        v.setTextViewText(R.id.fb_title, busy ?: if (on) "Brillo · $cur%" else "Brillo · apagado")
        v.setTextColor(R.id.fb_title, if (busy != null) look.accent else look.text)
        v.setImageViewBitmap(R.id.fb_open, Skin.iconButton((28 * s).toInt(), look, s))
        if (!preview) v.setOnClickPendingIntent(R.id.fb_open, openPanel(ctx, "bright"))

        val steps = 20
        val barWdp = (wDp - 20).coerceAtLeast(60)
        val barHdp = (hDp - 20 - 30).coerceAtLeast(24)
        val sliceW = max(((barWdp * s) / steps).toInt(), 2)
        val barH = (barHdp * s).toInt()
        val bar = Skin.sliderBar(sliceW * steps, barH, if (on) cur / 100f else 0f, look, s)
        for (i in 0 until steps) {
            val id = ctx.resources.getIdentifier("fb_" + (i + 1), "id", ctx.packageName)
            v.setImageViewBitmap(id, Bitmap.createBitmap(bar, i * sliceW, 0, sliceW, bar.height))
            v.setInt(id, "setImageAlpha", if (busy != null) 165 else 255)
            if (!preview) v.setOnClickPendingIntent(id, action(ctx, LedActions.BRIGHT, (i + 1) * 5, 0))
        }
        return v
    }

    /** Círculo cromático: 9x9 zonas tocables sobre el círculo, colores propios y botón de ventana flotante. */
    fun wheelView(ctx: Context, wDp: Int, hDp: Int, preview: Boolean): RemoteViews {
        val look = Store.cfg(ctx, WKey.WHEEL).look()
        val s = scale(ctx)
        val on = Store.isOn(ctx)
        val curColor = Store.color(ctx)
        val busy = if (preview) null else Store.busyText(ctx)
        val v = RemoteViews(ctx.packageName, R.layout.widget_wheel)
        v.setImageViewBitmap(R.id.wh_bg, Skin.card((wDp * s).toInt(), (hDp * s).toInt(), look, s))

        val wcDp = ((wDp - 16 - 8) / 2f).coerceAtLeast(60f)
        val hcDp = (hDp - 16f).coerceAtLeast(60f)
        val wPx = (wcDp * s).toInt()
        val hPx = (hcDp * s).toInt()
        v.setImageViewBitmap(R.id.wh_img, Skin.wheel(wPx, hPx, curColor, on, look, s))
        v.setInt(R.id.wh_img, "setImageAlpha", if (busy != null) 190 else 255)
        if (!preview) {
            val cx = wPx / 2f
            val cy = hPx / 2f
            val rad = Skin.wheelRadius(wPx, hPx, s)
            for (r in 0 until 9) {
                for (c in 0 until 9) {
                    val x = (c + 0.5f) / 9f * wPx
                    val y = (r + 0.5f) / 9f * hPx
                    val col = Skin.wheelColorAt(x - cx, y - cy, rad) ?: continue
                    val id = ctx.resources.getIdentifier("wz_" + r + "_" + c, "id", ctx.packageName)
                    v.setOnClickPendingIntent(id, action(ctx, LedActions.COLOR, 0, col))
                }
            }
        }

        v.setTextViewText(R.id.wh_title, busy ?: "Colores")
        v.setTextColor(R.id.wh_title, if (busy != null) look.accent else look.text)
        v.setImageViewBitmap(R.id.wh_open, Skin.iconButton((26 * s).toInt(), look, s))
        if (!preview) v.setOnClickPendingIntent(R.id.wh_open, openPanel(ctx, "color"))

        val dotPx = (30 * s).toInt()
        val savedIds = intArrayOf(R.id.ws1, R.id.ws2, R.id.ws3, R.id.ws4, R.id.ws5, R.id.ws6)
        val pinned = Store.saved(ctx).filter { it.pinned }.take(6)
        val cc = curColor and 0xFFFFFF
        for (i in savedIds.indices) {
            if (i < pinned.size) {
                val c = pinned[i].color
                val sel = on && (c and 0xFFFFFF) == cc
                v.setImageViewBitmap(savedIds[i], Skin.dot(dotPx, c, sel, false, look, s))
                if (!preview) v.setOnClickPendingIntent(savedIds[i], action(ctx, LedActions.COLOR, 0, c))
            } else {
                v.setImageViewBitmap(savedIds[i], Skin.dot(dotPx, 0, false, true, look, s))
                if (!preview) v.setOnClickPendingIntent(savedIds[i], openApp(ctx))
            }
        }
        return v
    }

    /** Redibuja todos los widgets que estén en la pantalla de inicio. */
    fun refreshAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        fun upd(cls: Class<*>, build: (Int) -> RemoteViews) {
            for (id in mgr.getAppWidgetIds(ComponentName(ctx, cls))) {
                try { mgr.updateAppWidget(id, build(id)) } catch (_: Exception) {}
            }
        }
        upd(SwitchWidget::class.java) { switchFor(ctx, mgr, it) }
        upd(PowerWidget::class.java) { powerFor(ctx, mgr, it) }
        upd(BrightnessWidget::class.java) { brightnessFor(ctx, mgr, it) }
        upd(ColorWidget::class.java) { colorFor(ctx, mgr, it) }
        upd(FineBrightWidget::class.java) { fineFor(ctx, mgr, it) }
        upd(WheelWidget::class.java) { wheelFor(ctx, mgr, it) }
    }
}
