package com.luces.led

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Typeface

/** Vibración corta para confirmar toques. */
object Haptics {
    @Suppress("DEPRECATION")
    private fun vib(ctx: Context): Vibrator? {
        return if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    @Suppress("DEPRECATION")
    private fun fire(ctx: Context, effect: VibrationEffect) {
        val v = vib(ctx) ?: return
        if (!v.hasVibrator()) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .build()
            v.vibrate(effect, attrs)
        } catch (_: Exception) {
            try { v.vibrate(effect) } catch (_: Exception) {}
        }
    }

    fun tick(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 29) fire(ctx, VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        else fire(ctx, VibrationEffect.createOneShot(18, 110))
    }

    fun error(ctx: Context) {
        fire(ctx, VibrationEffect.createWaveform(longArrayOf(0, 35, 70, 35), -1))
    }
}

/** Piezas de interfaz y animaciones compartidas por las pantallas. */
object Ui {
    val BG = 0xFF0E0F14.toInt()
    val CARD = 0xFF1A1B23.toInt()
    val CARD2 = 0xFF262833.toInt()
    val ACCENT = 0xFFFFC107.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val SUB = 0xFFA0A4B0.toInt()

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(ctx: Context, color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(ctx, r).toFloat()
        return g
    }

    fun lp(ctx: Context, w: Int = MATCH, h: Int = WRAP, top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = dp(ctx, top)
        return p
    }

    fun label(ctx: Context, t: String, size: Float, color: Int = TEXT, bold: Boolean = false): TextView {
        val tv = TextView(ctx)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        return tv
    }

    fun pill(ctx: Context, t: String, filled: Boolean, onClick: () -> Unit): Button {
        val b = Button(ctx)
        b.text = t
        b.setAllCaps(false)
        b.textSize = 14f
        stylePill(ctx, b, filled)
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        press(b)
        return b
    }

    fun stylePill(ctx: Context, b: Button, filled: Boolean) {
        b.setTextColor(if (filled) 0xFF111111.toInt() else TEXT)
        b.background = rounded(ctx, if (filled) ACCENT else CARD2, 24)
    }

    /** Se encoge al tocar y rebota al soltar. */
    @SuppressLint("ClickableViewAccessibility")
    fun press(v: View, scale: Float = 0.93f) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(scale).scaleY(scale).setDuration(90)
                        .setInterpolator(DecelerateInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(OvershootInterpolator(3.2f)).start()
            }
            false
        }
    }

    /** Rebote corto (por ejemplo al seleccionar algo). */
    fun bounce(v: View) {
        v.animate().cancel()
        v.scaleX = 0.86f
        v.scaleY = 0.86f
        v.animate().scaleX(1f).scaleY(1f).setDuration(420)
            .setInterpolator(OvershootInterpolator(3.4f)).start()
    }

    /** Entrada escalonada: aparecen subiendo y con fundido. */
    fun enter(views: List<View>) {
        views.forEachIndexed { i, v ->
            v.animate().cancel()
            v.alpha = 0f
            v.translationY = 28f * v.resources.displayMetrics.density
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(70L * i + 60L).setDuration(460)
                .setInterpolator(DecelerateInterpolator(1.8f)).start()
        }
    }
}
