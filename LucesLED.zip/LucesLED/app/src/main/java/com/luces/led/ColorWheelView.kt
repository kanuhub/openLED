package com.luces.led

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Rueda de color (tono + saturación). onPick(color, soltado). */
class ColorWheelView(ctx: Context) : View(ctx) {
    var onPick: ((Int, Boolean) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private var hue = 0f
    private var sat = 0f
    private var cx = 0f
    private var cy = 0f
    private var r = 0f
    private val huePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val satPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
        color = Color.WHITE
    }

    fun setColor(c: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hue = hsv[0]
        sat = hsv[1]
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cx = w / 2f
        cy = h / 2f
        r = min(w, h) / 2f - 14f * density
        huePaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED),
            null
        )
        satPaint.shader = RadialGradient(cx, cy, r, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawCircle(cx, cy, r, huePaint)
        canvas.drawCircle(cx, cy, r, satPaint)
        val rad = Math.toRadians(hue.toDouble())
        val tx = cx + (r * sat * cos(rad)).toFloat()
        val ty = cy + (r * sat * sin(rad)).toFloat()
        fill.color = Color.HSVToColor(floatArrayOf(hue, sat, 1f))
        canvas.drawCircle(tx, ty, 13f * density, fill)
        canvas.drawCircle(tx, ty, 13f * density, ring)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val dx = e.x - cx
                val dy = e.y - cy
                val dist = hypot(dx, dy)
                var ang = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
                if (ang < 0) ang += 360f
                hue = ang
                sat = min(dist, r) / r
                invalidate()
                onPick?.invoke(
                    Color.HSVToColor(floatArrayOf(hue, sat, 1f)),
                    e.actionMasked == MotionEvent.ACTION_UP
                )
            }
        }
        return true
    }
}
