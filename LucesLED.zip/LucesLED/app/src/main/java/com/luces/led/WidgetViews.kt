package com.luces.led

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

class SwitchWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        m.updateAppWidget(ids, WidgetViews.switchView(ctx))
    }
}

class PowerWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        m.updateAppWidget(ids, WidgetViews.powerView(ctx))
    }
}

class BrightnessWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        m.updateAppWidget(ids, WidgetViews.brightnessView(ctx))
    }
}

class ColorWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        m.updateAppWidget(ids, WidgetViews.colorView(ctx))
    }
}

object WidgetViews {
    private val AMBER = 0xFFFFC107.toInt()
    private val GRAY = 0xFF6B6F7B.toInt()

    fun action(ctx: Context, action: String, level: Int = 0, color: Int = 0): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java).setAction(action)
            .setData(Uri.parse("led://$action/$level/$color"))
            .putExtra("level", level)
            .putExtra("color", color)
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun openApp(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

    fun switchView(ctx: Context): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_switch)
        val on = Store.isOn(ctx)
        v.setImageViewResource(R.id.sw_track, if (on) R.drawable.switch_on else R.drawable.switch_off)
        v.setTextViewText(R.id.sw_state, if (on) "Encendidas" else "Apagadas")
        v.setInt(R.id.sw_icon, "setColorFilter", if (on) AMBER else GRAY)
        v.setOnClickPendingIntent(R.id.sw_root, action(ctx, LedActions.TOGGLE))
        return v
    }

    fun powerView(ctx: Context): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_power)
        v.setImageViewResource(R.id.pw_btn, if (Store.isOn(ctx)) R.drawable.power_on else R.drawable.power_off)
        v.setOnClickPendingIntent(R.id.pw_btn, action(ctx, LedActions.TOGGLE))
        return v
    }

    fun brightnessView(ctx: Context): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_brightness)
        val cur = Store.brightness(ctx)
        val on = Store.isOn(ctx)
        v.setTextViewText(R.id.br_title, if (on) "Brillo · $cur%" else "Brillo · apagado")
        val ids = intArrayOf(R.id.br_1, R.id.br_2, R.id.br_3, R.id.br_4, R.id.br_5)
        val levels = intArrayOf(20, 40, 60, 80, 100)
        for (i in ids.indices) {
            val lit = on && levels[i] <= cur
            v.setInt(ids[i], "setBackgroundResource", if (lit) R.drawable.seg_on else R.drawable.seg_off)
            v.setTextColor(ids[i], if (lit) 0xFF111111.toInt() else 0xFFA0A4B0.toInt())
            v.setOnClickPendingIntent(ids[i], action(ctx, LedActions.BRIGHT, levels[i], 0))
        }
        return v
    }

    fun colorView(ctx: Context): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_colors)
        val presetIds = intArrayOf(R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5, R.id.c6, R.id.c7, R.id.c8)
        for (i in presetIds.indices) {
            val c = Palette.COLORS[i]
            v.setInt(presetIds[i], "setColorFilter", c)
            v.setOnClickPendingIntent(presetIds[i], action(ctx, LedActions.COLOR, 0, c))
        }
        val savedIds = intArrayOf(R.id.s1, R.id.s2, R.id.s3, R.id.s4, R.id.s5, R.id.s6)
        val pinned = Store.saved(ctx).filter { it.pinned }.take(6)
        for (i in savedIds.indices) {
            if (i < pinned.size) {
                val c = pinned[i].color
                v.setInt(savedIds[i], "setColorFilter", c)
                v.setOnClickPendingIntent(savedIds[i], action(ctx, LedActions.COLOR, 0, c))
            } else {
                v.setInt(savedIds[i], "setColorFilter", 0x33FFFFFF)
                v.setOnClickPendingIntent(savedIds[i], openApp(ctx))
            }
        }
        return v
    }

    /** Redibuja todos los widgets que estén en la pantalla de inicio. */
    fun refreshAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        fun upd(cls: Class<*>, build: (Context) -> RemoteViews) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isNotEmpty()) mgr.updateAppWidget(ids, build(ctx))
        }
        upd(SwitchWidget::class.java) { switchView(it) }
        upd(PowerWidget::class.java) { powerView(it) }
        upd(BrightnessWidget::class.java) { brightnessView(it) }
        upd(ColorWidget::class.java) { colorView(it) }
    }
}
