package com.luces.led

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.UUID

/**
 * Comandos de la tira (protocolo tipo ELK-BLEDOM).
 * Si el color o el brillo no responden en tu tira, se ajustan aquí.
 */
object Led {
    private fun b(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    val ON = b(0x7E, 0x04, 0x04, 0xF0, 0x00, 0x01, 0xFF, 0x00, 0xEF)
    val OFF = b(0x7E, 0x04, 0x04, 0x00, 0x00, 0x00, 0xFF, 0x00, 0xEF)

    fun color(c: Int) = b(0x7E, 0x07, 0x05, 0x03, Color.red(c), Color.green(c), Color.blue(c), 0x10, 0xEF)
    fun brightness(percent: Int) = b(0x7E, 0x04, 0x01, percent.coerceIn(0, 100), 0x01, 0xFF, 0xFF, 0x00, 0xEF)
}

/**
 * Mantiene la conexión Bluetooth abierta unos segundos después del último comando,
 * así los toques seguidos son casi instantáneos.
 *
 * El callback recibe: true = enviado, false = error, null = reemplazado por una orden más nueva.
 * Todo corre en el hilo principal.
 */
@SuppressLint("MissingPermission")
object BleController {
    private val SERVICE: UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")
    private val CHARACTERISTIC: UUID = UUID.fromString("0000fff3-0000-1000-8000-00805f9b34fb")
    private const val IDLE_MS = 20000L
    private const val STALE_MS = 30000L

    private class Req(val ctx: Context, val mac: String, val cmds: List<ByteArray>, val done: (Boolean?) -> Unit) {
        var retried = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var chr: BluetoothGattCharacteristic? = null
    private var curMac: String? = null
    private var ready = false
    private var connecting = false
    private var current: Req? = null
    private var index = 0
    private var pending: Req? = null
    private var lastActivity = 0L

    private val idleRunnable = Runnable {
        if (current == null && pending == null) close(null)
    }
    private val watchdog = Runnable { close(false) }

    /** Abre la conexión por adelantado (por ejemplo al abrir la app). */
    fun warmUp(ctx: Context, mac: String) {
        if (ready || connecting) return
        connect(ctx.applicationContext, mac)
    }

    fun send(ctx: Context, mac: String, cmds: List<ByteArray>, done: (Boolean?) -> Unit) {
        dispatch(Req(ctx.applicationContext, mac, cmds, done))
    }

    private fun dispatch(req: Req) {
        if ((ready || connecting) && curMac != req.mac) close(null)
        if (ready && SystemClock.elapsedRealtime() - lastActivity > STALE_MS) close(null)
        handler.removeCallbacks(idleRunnable)
        if (ready && current == null) {
            startWrite(req)
            return
        }
        pending?.done?.invoke(null)
        pending = req
        if (!ready && !connecting) connect(req.ctx, req.mac)
    }

    private fun connect(ctx: Context, mac: String) {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            close(false)
            return
        }
        connecting = true
        curMac = mac
        try {
            gatt = adapter.getRemoteDevice(mac).connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) {
            close(false)
            return
        }
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, 8000)
    }

    private fun startWrite(req: Req) {
        current = req
        index = 0
        handler.removeCallbacks(idleRunnable)
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, 3000)
        writeCurrent()
    }

    private fun writeCurrent() {
        val g = gatt ?: return
        val c = chr ?: return
        val data = current?.cmds?.getOrNull(index) ?: return
        lastActivity = SystemClock.elapsedRealtime()
        if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, data, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
        } else {
            c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            c.value = data
            g.writeCharacteristic(c)
        }
    }

    private fun scheduleIdle() {
        handler.removeCallbacks(idleRunnable)
        handler.postDelayed(idleRunnable, IDLE_MS)
    }

    private fun close(fail: Boolean?) {
        handler.removeCallbacks(idleRunnable)
        handler.removeCallbacks(watchdog)
        val wasReady = ready
        val g = gatt
        gatt = null
        chr = null
        ready = false
        connecting = false
        curMac = null
        if (g != null) {
            try { g.disconnect() } catch (_: Exception) {}
            handler.postDelayed({ try { g.close() } catch (_: Exception) {} }, 300)
        }
        val cur = current
        val p = pending
        current = null
        pending = null

        // Si la conexión vieja estaba caída, reintenta una vez con una conexión nueva.
        if (fail == false && wasReady) {
            val r = p ?: cur
            if (r != null && !r.retried) {
                if (p != null && cur != null) cur.done(null)
                r.retried = true
                pending = r
                connect(r.ctx, r.mac)
                return
            }
        }
        cur?.done?.invoke(fail)
        p?.done?.invoke(fail)
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            handler.post {
                if (g !== gatt) {
                    try { g.close() } catch (_: Exception) {}
                    return@post
                }
                if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
                else if (newState == BluetoothProfile.STATE_DISCONNECTED) close(false)
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            handler.post {
                if (g !== gatt) return@post
                val c = g.getService(SERVICE)?.getCharacteristic(CHARACTERISTIC)
                if (c == null) {
                    close(false)
                    return@post
                }
                chr = c
                ready = true
                connecting = false
                handler.removeCallbacks(watchdog)
                lastActivity = SystemClock.elapsedRealtime()
                val p = pending
                if (p != null) {
                    pending = null
                    startWrite(p)
                } else {
                    scheduleIdle()
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            handler.post {
                if (g !== gatt) return@post
                val cur = current ?: return@post
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    close(false)
                    return@post
                }
                index++
                if (index < cur.cmds.size) {
                    handler.postDelayed({ if (current === cur) writeCurrent() }, 50)
                } else {
                    handler.removeCallbacks(watchdog)
                    current = null
                    lastActivity = SystemClock.elapsedRealtime()
                    cur.done(true)
                    val p = pending
                    if (p != null) {
                        pending = null
                        startWrite(p)
                    } else if (current == null) {
                        scheduleIdle()
                    }
                }
            }
        }
    }
}
