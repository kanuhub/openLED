package com.luces.led

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID

/**
 * Comandos de la tira (protocolo tipo ELK-BLEDOM, el mismo que ya te funcionó para encender/apagar).
 * Si el color o el brillo no responden en tu tira, se ajustan aquí.
 */
object Led {
    private fun b(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    val ON = b(0x7E, 0x04, 0x04, 0xF0, 0x00, 0x01, 0xFF, 0x00, 0xEF)
    val OFF = b(0x7E, 0x04, 0x04, 0x00, 0x00, 0x00, 0xFF, 0x00, 0xEF)

    fun color(c: Int) = b(0x7E, 0x07, 0x05, 0x03, Color.red(c), Color.green(c), Color.blue(c), 0x10, 0xEF)
    fun brightness(percent: Int) = b(0x7E, 0x04, 0x01, percent.coerceIn(0, 100), 0x01, 0xFF, 0xFF, 0x00, 0xEF)
}

/**
 * Se conecta, envía una lista de comandos en orden y se desconecta.
 * Si llega otra petición mientras hay una en curso, queda en espera (solo se conserva la última).
 * El callback recibe true = ok, false = error, null = petición reemplazada por otra más nueva.
 */
@SuppressLint("MissingPermission")
object BleController {
    private val SERVICE: UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")
    private val CHARACTERISTIC: UUID = UUID.fromString("0000fff3-0000-1000-8000-00805f9b34fb")

    private class Req(val ctx: Context, val mac: String, val cmds: List<ByteArray>, val done: (Boolean?) -> Unit)

    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var pending: Req? = null

    fun send(ctx: Context, mac: String, cmds: List<ByteArray>, done: (Boolean?) -> Unit) {
        val req = Req(ctx.applicationContext, mac, cmds, done)
        if (busy) {
            pending?.done?.invoke(null)
            pending = req
            return
        }
        start(req)
    }

    private fun start(req: Req) {
        val adapter = req.ctx.getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter == null || !adapter.isEnabled) { req.done(false); return }

        busy = true
        var finished = false
        var ok = false
        var index = 0
        var gatt: BluetoothGatt? = null

        fun finish() {
            if (finished) return
            finished = true
            try { gatt?.close() } catch (_: Exception) {}
            busy = false
            req.done(ok)
            val next = pending
            if (next != null) { pending = null; start(next) }
        }

        fun writeNext(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val data = req.cmds[index]
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, data, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                c.value = data
                g.writeCharacteristic(c)
            }
        }

        val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
                else if (newState == BluetoothProfile.STATE_DISCONNECTED) handler.post { finish() }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                val c = g.getService(SERVICE)?.getCharacteristic(CHARACTERISTIC)
                if (c == null) { g.disconnect(); return }
                writeNext(g, c)
            }

            override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) { g.disconnect(); return }
                index++
                if (index < req.cmds.size) {
                    handler.postDelayed({ if (!finished) writeNext(g, c) }, 60)
                } else {
                    ok = true
                    g.disconnect()
                }
            }
        }

        try {
            gatt = adapter.getRemoteDevice(req.mac).connectGatt(req.ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) {
            finish()
            return
        }
        handler.postDelayed({ finish() }, 8000)
    }
}
