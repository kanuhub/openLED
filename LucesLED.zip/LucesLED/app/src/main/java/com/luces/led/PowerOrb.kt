package com.luces.led

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

/** Botón grande de encendido: el color se funde, brilla al encender y pulsa mientras envía. */
class PowerOrb(ctx: Context) : View(ctx) {
    private val density = resources.displayMetrics.density
    private var accent = 0xFFFFC107.toInt()
    private var level = 0f
    private var target = 0f
    private var pulse = 0f
    private var levelAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val iconP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    fun setOn(on: Boolean) {
        val t = if (on) 1f else 0f
        if (t == target) return
        target = t
        levelAnim?.cancel()
        val anim = ValueAnimator.ofFloat(level, t)
        anim.duration = 420
        anim.interpolator = DecelerateInterpolator(1.6f)
        anim.addUpdateListener {
            level = it.animatedValue as Float
            invalidate()
        }
        anim.start()
        levelAnim = anim
    }

    fun setBusy(busy: Boolean) {
        if (busy) {
            if (pulseAnim != null) return
            val anim = ValueAnimator.ofFloat(0f, 1f)
            anim.duration = 950
            anim.repeatCount = ValueAnimator.INFINITE
            anim.addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            anim.start()
            pulseAnim = anim
        } else {
            pulseAnim?.cancel()
            pulseAnim = null
            pulse = 0f
            invalidate()
        }
    }

    override fun onDetachedFromWindow() {
        levelAnim?.cancel()
        pulseAnim?.cancel()
        pulseAnim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.55f
        if (level > 0.01f) {
            glow.shader = RadialGradient(
                cx, cy, r * 2.1f, Skin.a(accent, 0.55f * level), Skin.a(accent, 0f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r * 2.1f, glow)
        }
        if (pulse > 0f) {
            ringP.color = Skin.a(accent, (1f - pulse) * 0.75f)
            ringP.strokeWidth = 3f * density
            canvas.drawCircle(cx, cy, r * (1f + 0.6f * pulse), ringP)
        }
        val base = Skin.blend(0xFF2A2C35.toInt(), accent, level)
        disc.shader = LinearGradient(
            0f, cy - r, 0f, cy + r, Skin.lighten(base, 0.18f), Skin.darken(base, 0.14f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, disc)
        ringP.color = Skin.a(0xFFFFFFFF.toInt(), 0.22f)
        ringP.strokeWidth = 2f * density
        canvas.drawCircle(cx, cy, r - density, ringP)

        iconP.color = Skin.blend(0xFF8A8E9A.toInt(), 0xFF111111.toInt(), level)
        iconP.strokeWidth = r * 0.14f
        val rho = r * 0.42f
        canvas.drawArc(RectF(cx - rho, cy - rho + r * 0.03f, cx + rho, cy + rho + r * 0.03f), -55f, 290f, false, iconP)
        canvas.drawLine(cx, cy - rho * 1.25f, cx, cy - rho * 0.1f, iconP)
    }
}
