package com.luces.led

import android.graphics.Color

enum class Kind { GLASS, AERO, RETRO, MINIMAL, NEON, AMOLED, PASTEL, TERMINAL, AURORA }

class ThemeDef(
    val id: String,
    val name: String,
    val kind: Kind,
    val bg: Int,
    val accent: Int,
    val text: Int,
    val sub: Int,
    val radiusDp: Float,
    val mono: Boolean = false
)

object Themes {
    val ALL = listOf(
        ThemeDef("glass", "Liquid Glass", Kind.GLASS, 0xFFFFFFFF.toInt(), 0xFF34C759.toInt(), 0xFFFFFFFF.toInt(), 0xCCFFFFFF.toInt(), 26f),
        ThemeDef("aero", "Frutiger Aero", Kind.AERO, 0xFF39B7E8.toInt(), 0xFF7ED321.toInt(), 0xFF053350.toInt(), 0xFF0B5F8F.toInt(), 24f),
        ThemeDef("retro", "Retro 80s", Kind.RETRO, 0xFF2B1B4A.toInt(), 0xFFFF2E93.toInt(), 0xFFFFE9A8.toInt(), 0xFFB9A6E0.toInt(), 3f, true),
        ThemeDef("minimal", "Minimalista", Kind.MINIMAL, 0xFFF4F4F6.toInt(), 0xFF111111.toInt(), 0xFF111111.toInt(), 0xFF7A7A80.toInt(), 22f),
        ThemeDef("neon", "Neón", Kind.NEON, 0xFF0A0A14.toInt(), 0xFF00F5FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF8A8FB0.toInt(), 20f),
        ThemeDef("amoled", "AMOLED", Kind.AMOLED, 0xFF000000.toInt(), 0xFF30D158.toInt(), 0xFFFFFFFF.toInt(), 0xFF8E8E93.toInt(), 28f),
        ThemeDef("pastel", "Pastel", Kind.PASTEL, 0xFFFFE3EC.toInt(), 0xFFFF7FA8.toInt(), 0xFF5A3E4B.toInt(), 0xFF9B7F8C.toInt(), 30f),
        ThemeDef("terminal", "Terminal", Kind.TERMINAL, 0xFF030A03.toInt(), 0xFF00FF41.toInt(), 0xFF00FF41.toInt(), 0xFF1E9E3E.toInt(), 3f, true),
        ThemeDef("aurora", "Aurora", Kind.AURORA, 0xFF0B1026.toInt(), 0xFF7CFFCB.toInt(), 0xFFFFFFFF.toInt(), 0xFFA9B4D6.toInt(), 26f)
    )

    fun byId(id: String): ThemeDef = ALL.firstOrNull { it.id == id } ?: ALL[0]
}

object WKey {
    const val SWITCH = "switch"
    const val POWER = "power"
    const val BRIGHT = "bright"
    const val COLORS = "colors"
    val ALL = listOf(SWITCH, POWER, BRIGHT, COLORS)
}

/** Aspecto ya resuelto (tema + ajustes del usuario). */
class Look(
    val kind: Kind,
    val bg: Int,
    val accent: Int,
    val text: Int,
    val sub: Int,
    val radiusDp: Float,
    val opacity: Int,
    val mono: Boolean
)

/** Ajustes guardados por widget: tema, color de fondo, acento y opacidad (20-100). */
class Cfg(val theme: String, val bg: Int?, val accent: Int?, val opacity: Int) {
    fun look(): Look {
        val d = Themes.byId(theme)
        val bgc = bg ?: d.bg
        val acc = accent ?: d.accent
        var text = d.text
        var sub = d.sub
        if (bg != null && opacity >= 60 && d.kind != Kind.GLASS) {
            val light = Skin.lum(bgc) > 0.6f
            text = if (light) 0xFF111111.toInt() else Color.WHITE
            sub = if (light) 0xFF6B6B72.toInt() else 0xFFB0B4C0.toInt()
        }
        if (d.kind == Kind.TERMINAL) {
            text = acc
            sub = Skin.blend(acc, bgc, 0.45f)
        }
        return Look(d.kind, bgc, acc, text, sub, d.radiusDp, opacity, d.mono)
    }
}
