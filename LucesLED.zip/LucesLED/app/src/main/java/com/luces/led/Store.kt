package com.luces.led

import android.content.Context
import android.graphics.Color

object Palette {
    val COLORS = intArrayOf(
        0xFFFF1A1A.toInt(), 0xFFFF7A00.toInt(), 0xFFFFD60A.toInt(), 0xFF00E04B.toInt(),
        0xFF00E5FF.toInt(), 0xFF2255FF.toInt(), 0xFFFF2D95.toInt(), 0xFFFFFFFF.toInt()
    )
}

/** Estado guardado: dispositivo, encendido, brillo, color, colores propios y ajustes de temas. */
object Store {
    class Saved(val color: Int, val name: String, val pinned: Boolean)

    private fun p(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun mac(c: Context): String? = p(c).getString("mac", null)
    fun deviceName(c: Context): String? = p(c).getString("devname", null)
    fun setDevice(c: Context, mac: String, name: String) {
        p(c).edit().putString("mac", mac).putString("devname", name).apply()
    }

    fun isOn(c: Context) = p(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }

    fun brightness(c: Context) = p(c).getInt("bright", 100)
    fun setBrightness(c: Context, v: Int) { p(c).edit().putInt("bright", v).apply() }

    fun color(c: Context) = p(c).getInt("color", Color.WHITE)
    fun setColor(c: Context, v: Int) { p(c).edit().putInt("color", v).apply() }

    /** Texto mientras se envía una orden ("Encendiendo…"). Caduca solo a los 12 s. */
    fun setBusy(c: Context, text: String?) {
        p(c).edit().putString("busy", text).putLong("busy_ts", System.currentTimeMillis()).apply()
    }

    fun busyText(c: Context): String? {
        val t = p(c).getString("busy", null) ?: return null
        if (System.currentTimeMillis() - p(c).getLong("busy_ts", 0L) > 12000L) return null
        return t
    }

    fun cfg(c: Context, key: String): Cfg {
        val def = Cfg("glass", null, null, 100)
        val raw = p(c).getString("cfg_$key", null) ?: return def
        val parts = raw.split("|")
        if (parts.size < 4) return def
        return Cfg(parts[0], parts[1].toIntOrNull(), parts[2].toIntOrNull(), parts[3].toIntOrNull() ?: 100)
    }

    fun setCfg(c: Context, key: String, cfg: Cfg) {
        val s = cfg.theme + "|" + (cfg.bg?.toString() ?: "-") + "|" + (cfg.accent?.toString() ?: "-") + "|" + cfg.opacity
        p(c).edit().putString("cfg_$key", s).apply()
    }

    fun saved(c: Context): MutableList<Saved> {
        val raw = p(c).getString("saved", "") ?: ""
        val out = mutableListOf<Saved>()
        for (item in raw.split(";")) {
            if (item.isBlank()) continue
            val parts = item.split(",", limit = 3)
            if (parts.size < 3) continue
            val rgb = parts[0].toLongOrNull(16) ?: continue
            out.add(Saved((0xFF000000L or rgb).toInt(), parts[2], parts[1] == "1"))
        }
        return out
    }

    fun setSaved(c: Context, list: List<Saved>) {
        val s = list.joinToString(";") {
            String.format("%06X", it.color and 0xFFFFFF) + "," +
                (if (it.pinned) "1" else "0") + "," +
                it.name.replace(",", " ").replace(";", " ")
        }
        p(c).edit().putString("saved", s).apply()
    }
}
