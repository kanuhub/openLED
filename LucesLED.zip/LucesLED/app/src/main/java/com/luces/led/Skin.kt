package com.luces.led

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

/**
 * Dibuja por código el aspecto de los widgets (fondo, switch, botón, segmentos y puntos de color)
 * según el tema elegido. Todo se genera como imágenes porque los widgets de Android
 * no permiten efectos reales de desenfoque ni animaciones propias.
 */
object Skin {
    // ---------- color ----------
    fun a(color: Int, alpha: Float): Int =
        Color.argb((alpha.coerceIn(0f, 1f) * 255f).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    fun blend(c1: Int, c2: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val r = (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * k).toInt().coerceIn(0, 255)
        val g = (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * k).toInt().coerceIn(0, 255)
        val b = (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * k).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    fun lighten(c: Int, t: Float) = blend(c, Color.WHITE, t)
    fun darken(c: Int, t: Float) = blend(c, Color.BLACK, t)

    fun lum(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    fun onColor(bg: Int): Int = if (lum(bg) > 0.62f) 0xFF111111.toInt() else Color.WHITE

    // ---------- utilidades ----------
    private fun square(look: Look) = look.kind == Kind.RETRO || look.kind == Kind.TERMINAL
    private fun glossy(look: Look) =
        look.kind == Kind.GLASS || look.kind == Kind.AERO || look.kind == Kind.AURORA

    private fun paint(style: Paint.Style, color: Int = Color.BLACK): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = style
        p.color = color
        return p
    }

    private fun bitmap(w: Int, h: Int): Bitmap =
        Bitmap.createBitmap(max(w, 4), max(h, 4), Bitmap.Config.ARGB_8888)

    private fun scanlines(c: Canvas, rect: RectF, step: Float, thick: Float, color: Int) {
        val p = paint(Paint.Style.FILL, color)
        var y = rect.top + step / 2f
        while (y < rect.bottom) {
            c.drawRect(rect.left, y, rect.right, y + thick, p)
            y += step
        }
    }

    private fun trackOff(look: Look): Int = when (look.kind) {
        Kind.GLASS -> 0xFF9AA0AE.toInt()
        Kind.AERO -> 0xFF9FB6C4.toInt()
        Kind.AURORA -> 0xFF4A5372.toInt()
        Kind.RETRO -> 0xFF3C2A63.toInt()
        Kind.TERMINAL -> 0xFF0E2A0E.toInt()
        Kind.NEON -> 0xFF2A2A3C.toInt()
        Kind.AMOLED -> 0xFF2C2C2E.toInt()
        Kind.PASTEL -> 0xFFEBC9D6.toInt()
        Kind.MINIMAL -> if (lum(look.bg) > 0.6f) 0xFFD0D0D6.toInt() else 0xFF3A3A40.toInt()
    }

    /** Relleno del color de acento con el estilo del tema (brillo, neón, bloque...). */
    private fun fillAccent(c: Canvas, rect: RectF, r: Float, base: Int, look: Look, s: Float, active: Boolean) {
        when {
            glossy(look) -> {
                val p = paint(Paint.Style.FILL)
                p.shader = LinearGradient(
                    0f, rect.top, 0f, rect.bottom,
                    intArrayOf(lighten(base, 0.38f), base, darken(base, 0.18f)),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(rect, r, r, p)
                val hp = paint(Paint.Style.FILL)
                hp.shader = LinearGradient(
                    0f, rect.top, 0f, rect.centerY(),
                    a(Color.WHITE, 0.55f), a(Color.WHITE, 0f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(
                    RectF(rect.left + 2f * s, rect.top + 1.5f * s, rect.right - 2f * s, rect.centerY()),
                    r * 0.8f, r * 0.8f, hp
                )
                val bp = paint(Paint.Style.STROKE, a(Color.WHITE, 0.55f))
                bp.strokeWidth = 1.1f * s
                c.drawRoundRect(rect, r, r, bp)
            }
            look.kind == Kind.NEON -> {
                if (active) {
                    val gp = paint(Paint.Style.STROKE, a(base, 0.9f))
                    gp.strokeWidth = 3f * s
                    gp.maskFilter = BlurMaskFilter(5f * s, BlurMaskFilter.Blur.NORMAL)
                    c.drawRoundRect(rect, r, r, gp)
                    c.drawRoundRect(rect, r, r, paint(Paint.Style.FILL, a(base, 0.28f)))
                } else {
                    c.drawRoundRect(rect, r, r, paint(Paint.Style.FILL, a(base, 0.6f)))
                }
                val sp = paint(Paint.Style.STROKE, base)
                sp.strokeWidth = 1.4f * s
                c.drawRoundRect(rect, r, r, sp)
            }
            square(look) -> {
                c.drawRoundRect(rect, r, r, paint(Paint.Style.FILL, base))
                val sp = paint(Paint.Style.STROKE, darken(base, 0.45f))
                sp.strokeWidth = 2f * s
                c.drawRoundRect(rect, r, r, sp)
            }
            else -> c.drawRoundRect(rect, r, r, paint(Paint.Style.FILL, base))
        }
    }

    // ---------- fondo de tarjeta ----------
    fun card(w: Int, h: Int, look: Look, s: Float, radiusPx: Float = look.radiusDp * s): Bitmap {
        val bmp = bitmap(w, h)
        val c = Canvas(bmp)
        val wf = bmp.width.toFloat()
        val hf = bmp.height.toFloat()
        val full = RectF(0f, 0f, wf, hf)
        val r = min(radiusPx, min(wf, hf) / 2f)
        c.saveLayerAlpha(full, (look.opacity / 100f * 255f).toInt())

        when (look.kind) {
            Kind.GLASS -> {
                val rr = RectF(1f * s, 1f * s, wf - 1f * s, hf - 1f * s)
                c.drawRoundRect(rr, r, r, paint(Paint.Style.FILL, a(look.bg, 0.22f)))
                val tone = paint(Paint.Style.FILL)
                tone.shader = LinearGradient(
                    0f, 0f, 0f, hf,
                    intArrayOf(a(Color.WHITE, 0.30f), a(Color.WHITE, 0.04f), a(Color.BLACK, 0.22f)),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(rr, r, r, tone)
                c.save()
                val path = Path()
                path.addRoundRect(rr, r, r, Path.Direction.CW)
                c.clipPath(path)
                val hp = paint(Paint.Style.FILL)
                hp.shader = LinearGradient(
                    0f, 0f, 0f, hf * 0.5f, a(Color.WHITE, 0.42f), a(Color.WHITE, 0f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(RectF(3f * s, 3f * s, wf - 3f * s, hf * 0.5f), r * 0.8f, r * 0.8f, hp)
                c.restore()
                val bp = paint(Paint.Style.STROKE)
                bp.strokeWidth = 1.6f * s
                bp.shader = LinearGradient(
                    0f, 0f, wf, hf,
                    intArrayOf(a(Color.WHITE, 0.95f), a(Color.WHITE, 0.18f), a(Color.WHITE, 0.65f)),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(RectF(1.8f * s, 1.8f * s, wf - 1.8f * s, hf - 1.8f * s), r, r, bp)
            }
            Kind.AERO -> {
                val rr = RectF(1.5f * s, 1.5f * s, wf - 1.5f * s, hf - 1.5f * s)
                val body = paint(Paint.Style.FILL)
                body.shader = LinearGradient(
                    0f, 0f, 0f, hf,
                    intArrayOf(lighten(look.bg, 0.55f), look.bg, darken(look.bg, 0.22f)),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(rr, r, r, body)
                c.save()
                val path = Path()
                path.addRoundRect(rr, r, r, Path.Direction.CW)
                c.clipPath(path)
                val gp = paint(Paint.Style.FILL)
                gp.shader = LinearGradient(
                    0f, 0f, 0f, hf * 0.55f, a(Color.WHITE, 0.75f), a(Color.WHITE, 0.12f), Shader.TileMode.CLAMP
                )
                c.drawOval(RectF(-wf * 0.15f, -hf * 0.62f, wf * 1.15f, hf * 0.52f), gp)
                val glow = paint(Paint.Style.FILL)
                glow.shader = RadialGradient(
                    wf * 0.5f, hf * 1.05f, max(wf * 0.45f, 1f),
                    a(Color.WHITE, 0.45f), a(Color.WHITE, 0f), Shader.TileMode.CLAMP
                )
                c.drawRect(0f, hf * 0.5f, wf, hf, glow)
                c.restore()
                val rim = paint(Paint.Style.STROKE, a(Color.WHITE, 0.9f))
                rim.strokeWidth = 2f * s
                c.drawRoundRect(RectF(2.5f * s, 2.5f * s, wf - 2.5f * s, hf - 2.5f * s), r, r, rim)
                val outer = paint(Paint.Style.STROKE, a(darken(look.bg, 0.35f), 0.55f))
                outer.strokeWidth = 1f * s
                c.drawRoundRect(RectF(0.5f * s, 0.5f * s, wf - 0.5f * s, hf - 0.5f * s), r, r, outer)
            }
            Kind.RETRO -> {
                val off = 3f * s
                val face = RectF(0f, 0f, wf - off, hf - off)
                c.drawRoundRect(RectF(off, off, wf, hf), r, r, paint(Paint.Style.FILL, darken(look.accent, 0.45f)))
                c.drawRoundRect(face, r, r, paint(Paint.Style.FILL, look.bg))
                scanlines(c, face, 4f * s, 1f * s, a(Color.BLACK, 0.18f))
                val bp = paint(Paint.Style.STROKE, look.accent)
                bp.strokeWidth = 2.5f * s
                c.drawRoundRect(RectF(1.25f * s, 1.25f * s, face.right - 1.25f * s, face.bottom - 1.25f * s), r, r, bp)
            }
            Kind.MINIMAL -> {
                c.drawRoundRect(RectF(0.5f * s, 0.5f * s, wf - 0.5f * s, hf - 0.5f * s), r, r, paint(Paint.Style.FILL, look.bg))
                val bp = paint(
                    Paint.Style.STROKE,
                    if (lum(look.bg) > 0.6f) a(Color.BLACK, 0.10f) else a(Color.WHITE, 0.16f)
                )
                bp.strokeWidth = 1.2f * s
                c.drawRoundRect(RectF(1f * s, 1f * s, wf - 1f * s, hf - 1f * s), r, r, bp)
            }
            Kind.NEON -> {
                val rr = RectF(5f * s, 5f * s, wf - 5f * s, hf - 5f * s)
                c.drawRoundRect(rr, r, r, paint(Paint.Style.FILL, look.bg))
                val gp = paint(Paint.Style.STROKE, a(look.accent, 0.85f))
                gp.strokeWidth = 3f * s
                gp.maskFilter = BlurMaskFilter(5f * s, BlurMaskFilter.Blur.NORMAL)
                c.drawRoundRect(rr, r, r, gp)
                val sp = paint(Paint.Style.STROKE, look.accent)
                sp.strokeWidth = 1.5f * s
                c.drawRoundRect(rr, r, r, sp)
            }
            Kind.AMOLED -> {
                c.drawRoundRect(RectF(0.5f * s, 0.5f * s, wf - 0.5f * s, hf - 0.5f * s), r, r, paint(Paint.Style.FILL, look.bg))
                val bp = paint(Paint.Style.STROKE, a(Color.WHITE, 0.14f))
                bp.strokeWidth = 1f * s
                c.drawRoundRect(RectF(1f * s, 1f * s, wf - 1f * s, hf - 1f * s), r, r, bp)
            }
            Kind.PASTEL -> {
                val rr = RectF(1f * s, 1f * s, wf - 1f * s, hf - 1f * s)
                c.drawRoundRect(rr, r, r, paint(Paint.Style.FILL, look.bg))
                val sh = paint(Paint.Style.FILL)
                sh.shader = LinearGradient(
                    0f, 0f, 0f, hf,
                    a(Color.WHITE, 0.35f), a(darken(look.bg, 0.12f), 0.55f), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(rr, r, r, sh)
                val bp = paint(Paint.Style.STROKE, a(Color.WHITE, 0.95f))
                bp.strokeWidth = 2.5f * s
                c.drawRoundRect(RectF(2f * s, 2f * s, wf - 2f * s, hf - 2f * s), r, r, bp)
            }
            Kind.TERMINAL -> {
                val rr = RectF(1f * s, 1f * s, wf - 1f * s, hf - 1f * s)
                c.drawRoundRect(rr, r, r, paint(Paint.Style.FILL, look.bg))
                scanlines(c, rr, 3f * s, 1f * s, a(look.accent, 0.10f))
                val bp = paint(Paint.Style.STROKE, look.accent)
                bp.strokeWidth = 1.6f * s
                c.drawRoundRect(rr, r, r, bp)
            }
            Kind.AURORA -> {
                val rr = RectF(0.5f * s, 0.5f * s, wf - 0.5f * s, hf - 0.5f * s)
                c.drawRoundRect(rr, r, r, paint(Paint.Style.FILL, look.bg))
                c.save()
                val path = Path()
                path.addRoundRect(rr, r, r, Path.Direction.CW)
                c.clipPath(path)
                val blobs = arrayOf(
                    floatArrayOf(0.15f, 0.10f, 0.65f), floatArrayOf(0.88f, 0.95f, 0.60f), floatArrayOf(0.62f, 0.05f, 0.45f)
                )
                val colors = intArrayOf(look.accent, 0xFFB388FF.toInt(), 0xFF4FC3F7.toInt())
                for (i in blobs.indices) {
                    val bp = paint(Paint.Style.FILL)
                    val rad = max(wf * blobs[i][2], 1f)
                    bp.shader = RadialGradient(
                        wf * blobs[i][0], hf * blobs[i][1], rad,
                        a(colors[i], 0.55f), a(colors[i], 0f), Shader.TileMode.CLAMP
                    )
                    c.drawRect(0f, 0f, wf, hf, bp)
                }
                c.restore()
                val bp = paint(Paint.Style.STROKE, a(Color.WHITE, 0.18f))
                bp.strokeWidth = 1f * s
                c.drawRoundRect(RectF(1f * s, 1f * s, wf - 1f * s, hf - 1f * s), r, r, bp)
            }
        }
        c.restore()
        return bmp
    }

    // ---------- interruptor ----------
    fun switchTrack(w: Int, h: Int, on: Boolean, look: Look, s: Float): Bitmap {
        val bmp = bitmap(w, h)
        val c = Canvas(bmp)
        val wf = bmp.width.toFloat()
        val hf = bmp.height.toFloat()
        val sq = square(look)
        val r = if (sq) 3f * s else hf / 2f
        val rect = RectF(1.5f * s, 1.5f * s, wf - 1.5f * s, hf - 1.5f * s)
        val base = if (on) look.accent else trackOff(look)
        fillAccent(c, rect, r, base, look, s, on)

        val d = hf - 7f * s
        val cx = if (on) wf - 3.5f * s - d / 2f else 3.5f * s + d / 2f
        val cy = hf / 2f
        val knob = paint(Paint.Style.FILL)
        when {
            look.kind == Kind.NEON -> knob.color = if (on) look.accent else look.sub
            sq -> knob.color = look.text
            look.kind == Kind.MINIMAL -> knob.color = Color.WHITE
            else -> knob.shader = LinearGradient(
                0f, cy - d / 2f, 0f, cy + d / 2f, Color.WHITE, 0xFFDEDEE4.toInt(), Shader.TileMode.CLAMP
            )
        }
        if (!sq && look.kind != Kind.NEON) knob.setShadowLayer(2.5f * s, 0f, 1.2f * s, a(Color.BLACK, 0.35f))
        if (sq) c.drawRoundRect(RectF(cx - d / 2f, cy - d / 2f, cx + d / 2f, cy + d / 2f), 2f * s, 2f * s, knob)
        else c.drawCircle(cx, cy, d / 2f, knob)
        return bmp
    }

    // ---------- botón de encendido ----------
    private fun drawPowerIcon(c: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        val p = paint(Paint.Style.STROKE, color)
        p.strokeWidth = size * 0.075f
        p.strokeCap = Paint.Cap.ROUND
        val rho = size * 0.2f
        val dy = size * 0.01f
        c.drawArc(RectF(cx - rho, cy - rho + dy, cx + rho, cy + rho + dy), -55f, 290f, false, p)
        c.drawLine(cx, cy - rho * 1.25f, cx, cy - rho * 0.1f, p)
    }

    fun powerButton(size: Int, on: Boolean, look: Look, s: Float): Bitmap {
        val sq = square(look)
        val sz = max(size, 8)
        val bmp = card(sz, sz, look, s, if (sq) 6f * s else sz / 2f)
        val c = Canvas(bmp)
        val f = sz.toFloat()
        if (on) {
            val inset = f * 0.14f
            val rect = RectF(inset, inset, f - inset, f - inset)
            fillAccent(c, rect, if (sq) 5f * s else rect.width() / 2f, look.accent, look, s, true)
        }
        drawPowerIcon(c, f / 2f, f / 2f, f, if (on) onColor(look.accent) else look.sub)
        return bmp
    }

    // ---------- segmento de brillo ----------
    fun segment(w: Int, h: Int, label: String, lit: Boolean, look: Look, s: Float): Bitmap {
        val bmp = bitmap(w, h)
        val c = Canvas(bmp)
        val wf = bmp.width.toFloat()
        val hf = bmp.height.toFloat()
        val sq = square(look)
        val r = if (sq) 3f * s else min(12f * s, hf / 2.2f)
        val rect = RectF(1f * s, 1f * s, wf - 1f * s, hf - 1f * s)
        if (lit) {
            fillAccent(c, rect, r, look.accent, look, s, true)
        } else if (look.kind == Kind.NEON) {
            val sp = paint(Paint.Style.STROKE, a(look.accent, 0.35f))
            sp.strokeWidth = 1.2f * s
            c.drawRoundRect(rect, r, r, sp)
        } else {
            val offFill = if (look.kind == Kind.GLASS || look.kind == Kind.AURORA) a(Color.WHITE, 0.18f) else a(look.text, 0.13f)
            c.drawRoundRect(rect, r, r, paint(Paint.Style.FILL, offFill))
        }
        val tp = paint(Paint.Style.FILL, if (lit) onColor(look.accent) else look.sub)
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = if (look.mono) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        tp.textSize = (hf * 0.45f).coerceIn(10f * s, 15f * s)
        val fm = tp.fontMetrics
        c.drawText(label, wf / 2f, hf / 2f - (fm.ascent + fm.descent) / 2f, tp)
        return bmp
    }

    // ---------- punto de color ----------
    fun dot(size: Int, color: Int, selected: Boolean, empty: Boolean, look: Look, s: Float): Bitmap {
        val sz = max(size, 12)
        val bmp = bitmap(sz, sz)
        val c = Canvas(bmp)
        val f = sz.toFloat()
        val cx = f / 2f
        val cy = f / 2f
        val m = f * 0.16f
        val cr = f / 2f - m

        if (empty) {
            val dp = paint(Paint.Style.STROKE, a(look.sub, 0.75f))
            dp.strokeWidth = 1.5f * s
            dp.pathEffect = DashPathEffect(floatArrayOf(4f * s, 4f * s), 0f)
            c.drawCircle(cx, cy, cr, dp)
            val pp = paint(Paint.Style.STROKE, a(look.sub, 0.75f))
            pp.strokeWidth = 1.5f * s
            pp.strokeCap = Paint.Cap.ROUND
            c.drawLine(cx - cr * 0.35f, cy, cx + cr * 0.35f, cy, pp)
            c.drawLine(cx, cy - cr * 0.35f, cx, cy + cr * 0.35f, pp)
            return bmp
        }

        when (look.kind) {
            Kind.GLASS, Kind.AURORA -> {
                val fp = paint(Paint.Style.FILL, color)
                fp.setShadowLayer(3f * s, 0f, 1.5f * s, a(Color.BLACK, 0.35f))
                c.drawCircle(cx, cy, cr, fp)
                val hp = paint(Paint.Style.FILL)
                hp.shader = RadialGradient(
                    cx - cr * 0.3f, cy - cr * 0.35f, max(cr * 0.8f, 1f),
                    a(Color.WHITE, 0.75f), a(Color.WHITE, 0f), Shader.TileMode.CLAMP
                )
                c.drawCircle(cx, cy, cr, hp)
                val rp = paint(Paint.Style.STROKE, a(Color.WHITE, 0.65f))
                rp.strokeWidth = 1.2f * s
                c.drawCircle(cx, cy, cr, rp)
            }
            Kind.AERO -> {
                val bp = paint(Paint.Style.FILL)
                bp.shader = RadialGradient(
                    cx, cy + cr * 0.3f, max(cr * 1.15f, 1f),
                    intArrayOf(lighten(color, 0.5f), color, darken(color, 0.3f)),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
                c.drawCircle(cx, cy, cr, bp)
                val gp = paint(Paint.Style.FILL)
                gp.shader = LinearGradient(
                    0f, cy - cr, 0f, cy, a(Color.WHITE, 0.85f), a(Color.WHITE, 0.1f), Shader.TileMode.CLAMP
                )
                c.drawOval(RectF(cx - cr * 0.68f, cy - cr * 0.95f, cx + cr * 0.68f, cy - cr * 0.05f), gp)
                val rp = paint(Paint.Style.STROKE, a(Color.WHITE, 0.9f))
                rp.strokeWidth = 1.6f * s
                c.drawCircle(cx, cy, cr, rp)
            }
            Kind.RETRO, Kind.TERMINAL -> {
                val o = 2f * s
                c.drawRoundRect(RectF(cx - cr + o, cy - cr + o, cx + cr + o, cy + cr + o), 2f * s, 2f * s, paint(Paint.Style.FILL, a(Color.BLACK, 0.6f)))
                val sq = RectF(cx - cr, cy - cr, cx + cr, cy + cr)
                c.drawRoundRect(sq, 2f * s, 2f * s, paint(Paint.Style.FILL, color))
                val bp = paint(Paint.Style.STROKE, look.text)
                bp.strokeWidth = 2f * s
                c.drawRoundRect(sq, 2f * s, 2f * s, bp)
            }
            Kind.NEON -> {
                val gp = paint(Paint.Style.STROKE, a(color, 0.95f))
                gp.strokeWidth = 3f * s
                gp.maskFilter = BlurMaskFilter(4f * s, BlurMaskFilter.Blur.NORMAL)
                c.drawCircle(cx, cy, cr, gp)
                c.drawCircle(cx, cy, cr, paint(Paint.Style.FILL, a(color, 0.85f)))
                val sp = paint(Paint.Style.STROKE, color)
                sp.strokeWidth = 1.4f * s
                c.drawCircle(cx, cy, cr, sp)
            }
            else -> {
                c.drawCircle(cx, cy, cr, paint(Paint.Style.FILL, color))
                val rp = paint(Paint.Style.STROKE, if (lum(look.bg) > 0.6f) a(Color.BLACK, 0.22f) else a(Color.WHITE, 0.28f))
                rp.strokeWidth = 1.2f * s
                c.drawCircle(cx, cy, cr, rp)
            }
        }

        if (selected) {
            val sp = paint(Paint.Style.STROKE, if (look.kind == Kind.AERO || lum(look.bg) > 0.6f) 0xFF111111.toInt() else Color.WHITE)
            sp.strokeWidth = 2.2f * s
            c.drawCircle(cx, cy, f / 2f - m * 0.35f, sp)
        }
        return bmp
    }
}
