package com.luces.led

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private val BG = 0xFF12131A.toInt()
private val CARD = 0xFF1E1F26.toInt()
private val ACCENT = 0xFFFFC107.toInt()
private val TEXT = 0xFFFFFFFF.toInt()
private val SUB = 0xFFA0A4B0.toInt()

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private lateinit var deviceTxt: TextView
    private lateinit var brightTxt: TextView
    private lateinit var preview: View
    private lateinit var hexTxt: TextView
    private lateinit var wheel: ColorWheelView
    private lateinit var savedBox: LinearLayout
    private var currentColor = 0xFFFFFFFF.toInt()

    // ---------- helpers de UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun label(t: String, size: Float, color: Int = TEXT, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(CARD, 20)
        layoutParams = lp(top = 14)
    }

    private fun pill(t: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t
        setAllCaps(false)
        textSize = 14f
        setTextColor(if (filled) 0xFF111111.toInt() else TEXT)
        background = rounded(if (filled) ACCENT else 0xFF2C2E38.toInt(), 24)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun circle(color: Int, size: Int): View = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(dp(1), 0x33FFFFFF)
        }
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply {
            setMargins(dp(3), dp(3), dp(3), dp(3))
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---------- pantalla ----------
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        currentColor = Store.color(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(32))
        }
        col.addView(label("Luces LED", 30f, TEXT, true))
        col.addView(label("Control por Bluetooth", 14f, SUB))

        // Conexión
        val c1 = card()
        c1.addView(label("Conexión", 16f, TEXT, true))
        deviceTxt = label("", 14f, SUB)
        c1.addView(deviceTxt, lp(top = 6))
        c1.addView(pill("Buscar / cambiar luces", true) { scanDialog() }, lp(top = 10))
        col.addView(c1)

        // Control
        val c2 = card()
        c2.addView(label("Control", 16f, TEXT, true))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pill("Encender", true) {
            sendAndStore(listOf(Led.ON)) { Store.setOn(this, true) }
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
        row.addView(pill("Apagar", false) {
            sendAndStore(listOf(Led.OFF)) { Store.setOn(this, false) }
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        c2.addView(row, lp(top = 10))
        brightTxt = label("Brillo: ${Store.brightness(this)}%", 14f, SUB)
        c2.addView(brightTxt, lp(top = 14))
        val seek = SeekBar(this).apply {
            max = 100
            progress = Store.brightness(this@MainActivity)
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                brightTxt.text = "Brillo: ${maxOf(p, 1)}%"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { applyBrightness(maxOf(sb.progress, 1)) }
        })
        c2.addView(seek, lp(top = 4))
        col.addView(c2)

        // Color
        val c3 = card()
        c3.addView(label("Color", 16f, TEXT, true))
        wheel = ColorWheelView(this)
        wheel.setColor(currentColor)
        wheel.onPick = { c, released ->
            currentColor = c
            updatePreview()
            if (released) applyColor(c)
        }
        c3.addView(wheel, lp(h = dp(250), top = 8))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        preview = View(this)
        info.addView(preview, LinearLayout.LayoutParams(dp(36), dp(36)))
        hexTxt = label("", 15f, TEXT, true)
        info.addView(hexTxt, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        info.addView(pill("Guardar color", true) { saveDialog() }, LinearLayout.LayoutParams(WRAP, WRAP))
        c3.addView(info, lp(top = 8))
        updatePreview()

        c3.addView(label("Colores rápidos", 13f, SUB), lp(top = 14))
        val presets = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for (i in Palette.COLORS.indices) {
            val c = Palette.COLORS[i]
            val v = circle(c, 28)
            v.setOnClickListener {
                currentColor = c
                wheel.setColor(c)
                updatePreview()
                applyColor(c)
            }
            presets.addView(v)
        }
        c3.addView(presets, lp(top = 6))
        col.addView(c3)

        // Mis colores
        val c4 = card()
        c4.addView(label("Mis colores", 16f, TEXT, true))
        c4.addView(label("Toca ★ para mostrar el color en el widget de colores (máx. 6).", 13f, SUB), lp(top = 4))
        savedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c4.addView(savedBox, lp(top = 6))
        col.addView(c4)

        // Ayuda
        val c5 = card()
        c5.addView(label("Widgets", 16f, TEXT, true))
        c5.addView(
            label("Mantén pulsado el escritorio → Widgets → Luces LED. Hay 4: Switch, Botón, Brillo y Colores.", 13f, SUB),
            lp(top = 4)
        )
        col.addView(c5)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(col)
        })

        refreshDevice()
        refreshSaved()
        requestPerms()
    }

    private fun refreshDevice() {
        val mac = Store.mac(this)
        deviceTxt.text = if (mac == null) "Sin luces seleccionadas"
        else "${Store.deviceName(this) ?: "Luces"} · $mac"
    }

    private fun updatePreview() {
        preview.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(currentColor)
            setStroke(dp(2), 0x55FFFFFF)
        }
        hexTxt.text = String.format("#%06X", currentColor and 0xFFFFFF)
    }

    // ---------- envío ----------
    private fun sendAndStore(cmds: List<ByteArray>, onOk: () -> Unit) {
        val mac = Store.mac(this)
        if (mac == null) { toast("Elige tus luces primero"); return }
        BleController.send(this, mac, cmds) { ok ->
            if (ok == true) {
                onOk()
                WidgetViews.refreshAll(this)
            } else if (ok == false) {
                toast("No se pudo conectar. ¿Está abierta la app LotusLamp?")
            }
        }
    }

    private fun applyBrightness(level: Int) {
        val cmds = mutableListOf<ByteArray>()
        if (!Store.isOn(this)) cmds.add(Led.ON)
        cmds.add(Led.brightness(level))
        sendAndStore(cmds) { Store.setBrightness(this, level); Store.setOn(this, true) }
    }

    private fun applyColor(c: Int) {
        val cmds = mutableListOf<ByteArray>()
        if (!Store.isOn(this)) cmds.add(Led.ON)
        cmds.add(Led.color(c))
        sendAndStore(cmds) { Store.setColor(this, c); Store.setOn(this, true) }
    }

    // ---------- colores guardados ----------
    private fun saveDialog() {
        val input = EditText(this).apply {
            hint = "Nombre (opcional)"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Guardar color")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val l = Store.saved(this)
                val hex = String.format("#%06X", currentColor and 0xFFFFFF)
                val nm = input.text.toString().trim().ifEmpty { hex }
                l.add(Store.Saved(currentColor, nm, l.count { it.pinned } < 6))
                Store.setSaved(this, l)
                refreshSaved()
                toast("Color guardado")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun refreshSaved() {
        savedBox.removeAllViews()
        val list = Store.saved(this)
        if (list.isEmpty()) {
            savedBox.addView(label("Aún no tienes colores guardados.", 13f, SUB))
        }
        list.forEachIndexed { i, s ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            row.addView(circle(s.color, 30))

            val name = label(s.name + "\n" + String.format("#%06X", s.color and 0xFFFFFF), 14f, TEXT)
            name.setOnClickListener {
                currentColor = s.color
                wheel.setColor(s.color)
                updatePreview()
                applyColor(s.color)
            }
            row.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) })

            val star = label(if (s.pinned) "★" else "☆", 24f, if (s.pinned) ACCENT else SUB)
            star.setPadding(dp(10), dp(6), dp(10), dp(6))
            star.setOnClickListener {
                val l = Store.saved(this)
                if (!s.pinned && l.count { it.pinned } >= 6) {
                    toast("Máximo 6 colores en el widget")
                    return@setOnClickListener
                }
                l[i] = Store.Saved(s.color, s.name, !s.pinned)
                Store.setSaved(this, l)
                refreshSaved()
            }
            row.addView(star)

            val del = label("✕", 18f, SUB)
            del.setPadding(dp(10), dp(6), dp(6), dp(6))
            del.setOnClickListener {
                val l = Store.saved(this)
                if (i < l.size) l.removeAt(i)
                Store.setSaved(this, l)
                refreshSaved()
            }
            row.addView(del)
            savedBox.addView(row)
        }
        WidgetViews.refreshAll(this)
    }

    // ---------- búsqueda de luces ----------
    private fun scanDialog() {
        if (!hasPerms()) { requestPerms(); return }
        val scanner = getSystemService(BluetoothManager::class.java).adapter?.bluetoothLeScanner
        if (scanner == null) { toast("Activa el Bluetooth"); return }

        val found = LinkedHashMap<String, String>()
        val ad = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        val cb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                val n = r.device.name ?: return
                if (found.put(r.device.address, n) == null) ad.add("$n  (${r.device.address})")
            }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Buscando luces… (cierra LotusLamp)")
            .setAdapter(ad) { _, i ->
                val mac = found.keys.elementAt(i)
                Store.setDevice(this, mac, found[mac] ?: "Luces")
                refreshDevice()
            }
            .setNegativeButton("Cerrar", null)
            .create()
        dlg.setOnDismissListener { try { scanner.stopScan(cb) } catch (_: Exception) {} }
        dlg.show()
        scanner.startScan(cb)
    }

    private fun perms() =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasPerms() = perms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    private fun requestPerms() { if (!hasPerms()) requestPermissions(perms(), 1) }
}
