package com.luces.led

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.Toast

/** Recibe los toques de los widgets. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val result = goAsync()
        LedActions.handle(ctx, intent) { result.finish() }
    }
}

object LedActions {
    const val TOGGLE = "com.luces.led.TOGGLE"
    const val BRIGHT = "com.luces.led.BRIGHT"
    const val COLOR = "com.luces.led.COLOR"

    fun handle(ctx: Context, intent: Intent, finish: () -> Unit) {
        val mac = Store.mac(ctx)
        if (mac == null) {
            Toast.makeText(ctx, "Abre la app y elige tus luces primero", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val cmds = mutableListOf<ByteArray>()
        var apply: () -> Unit = {}
        val isOn = Store.isOn(ctx)

        when (intent.action) {
            TOGGLE -> {
                val turnOn = !isOn
                cmds.add(if (turnOn) Led.ON else Led.OFF)
                apply = { Store.setOn(ctx, turnOn) }
            }
            BRIGHT -> {
                val level = intent.getIntExtra("level", 100)
                if (!isOn) cmds.add(Led.ON)
                cmds.add(Led.brightness(level))
                apply = { Store.setBrightness(ctx, level); Store.setOn(ctx, true) }
            }
            COLOR -> {
                val c = intent.getIntExtra("color", Color.WHITE)
                if (!isOn) cmds.add(Led.ON)
                cmds.add(Led.color(c))
                apply = { Store.setColor(ctx, c); Store.setOn(ctx, true) }
            }
            else -> { finish(); return }
        }

        BleController.send(ctx, mac, cmds) { ok ->
            if (ok == true) {
                apply()
                WidgetViews.refreshAll(ctx)
            } else if (ok == false) {
                Toast.makeText(ctx, "No se pudo conectar con las luces", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }
}
