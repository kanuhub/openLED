package com.luces.led

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** Pantalla "Temas": galería, vista previa en vivo, opacidad y colores de los widgets. */
@SuppressLint("SetTextI18n")
class ThemesPage(private val ctx: Context) {
    private var target = "all"
    private val s = WidgetViews.scale(ctx)
    private lateinit var previewBox: LinearLayout
    private lateinit var chipRow: LinearLayout
    private lateinit var galleryRow: LinearLayout
    private lateinit var opacityTxt: TextView
    private lateinit var opacitySeek: SeekBar
    private lateinit var bgRow: LinearLayout
    private lateinit var accentRow: LinearLayout
    private var ready = false

    private fun dp(v: Int) = Ui.dp(ctx, v)
    private fun keys(): List<String> = if (target == "all") WKey.ALL else listOf(target)
    private fun cur(): Cfg = Store.cfg(ctx, keys()[0])

    private fun update(f: (Cfg) -> Cfg) {
        for (k in keys()) Store.setCfg(ctx, k, f(Store.cfg(ctx, k)))
        WidgetViews.refreshAll(ctx)
        renderPreviews()
    }

    fun build(): LinearLayout {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(40))

        col.addView(Ui.label(ctx, "Temas de widgets", 22f, Ui.TEXT, true))
        col.addView(
            Ui.label(ctx, "Elige un estilo y ajústalo. Los widgets de tu pantalla de inicio se actualizan al instante.", 13f, Ui.SUB),
            Ui.lp(ctx, top = 4)
        )

        // A qué widget se aplica
        col.addView(Ui.label(ctx, "Aplicar a", 13f, Ui.SUB), Ui.lp(ctx, top = 16))
        val chipScroll = HorizontalScrollView(ctx)
        chipScroll.isHorizontalScrollBarEnabled = false
        chipRow = LinearLayout(ctx)
        chipRow.orientation = LinearLayout.HORIZONTAL
        chipScroll.addView(chipRow)
        col.addView(chipScroll, Ui.lp(ctx, top = 6))

        // Vista previa
        val previewWrap = LinearLayout(ctx)
        previewWrap.orientation = LinearLayout.VERTICAL
        previewWrap.setPadding(dp(12), dp(8), dp(12), dp(16))
        val wall = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF5B3DF5.toInt(), 0xFF1FA2FF.toInt(), 0xFF12D8A8.toInt())
        )
        wall.cornerRadius = dp(24).toFloat()
        previewWrap.background = wall
        previewBox = previewWrap
        col.addView(previewWrap, Ui.lp(ctx, top = 12))

        // Galería de estilos
        col.addView(Ui.label(ctx, "Estilo", 16f, Ui.TEXT, true), Ui.lp(ctx, top = 20))
        val gScroll = HorizontalScrollView(ctx)
        gScroll.isHorizontalScrollBarEnabled = false
        galleryRow = LinearLayout(ctx)
        galleryRow.orientation = LinearLayout.HORIZONTAL
        galleryRow.setPadding(dp(6), dp(10), dp(6), dp(10))
        val gwall = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF3A2C8F.toInt(), 0xFF1A6FA8.toInt(), 0xFF0E8C74.toInt())
        )
        gwall.cornerRadius = dp(20).toFloat()
        gScroll.background = gwall
        gScroll.addView(galleryRow)
        col.addView(gScroll, Ui.lp(ctx, top = 8))

        // Opacidad
        col.addView(Ui.label(ctx, "Opacidad", 16f, Ui.TEXT, true), Ui.lp(ctx, top = 20))
        opacityTxt = Ui.label(ctx, "", 13f, Ui.SUB)
        col.addView(opacityTxt, Ui.lp(ctx, top = 2))
        opacitySeek = SeekBar(ctx)
        opacitySeek.max = 80
        opacitySeek.progressTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
        opacitySeek.thumbTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
        opacitySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                opacityTxt.text = "${p + 20}%"
                if (fromUser && ready) {
                    for (k in keys()) {
                        val c = Store.cfg(ctx, k)
                        Store.setCfg(ctx, k, Cfg(c.theme, c.bg, c.accent, p + 20))
                    }
                    renderPreviews()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { WidgetViews.refreshAll(ctx) }
        })
        col.addView(opacitySeek, Ui.lp(ctx, top = 4))

        // Colores
        col.addView(Ui.label(ctx, "Color de fondo", 16f, Ui.TEXT, true), Ui.lp(ctx, top = 20))
        val bgScroll = HorizontalScrollView(ctx)
        bgScroll.isHorizontalScrollBarEnabled = false
        bgRow = LinearLayout(ctx)
        bgRow.orientation = LinearLayout.HORIZONTAL
        bgRow.gravity = Gravity.CENTER_VERTICAL
        bgScroll.addView(bgRow)
        col.addView(bgScroll, Ui.lp(ctx, top = 8))

        col.addView(Ui.label(ctx, "Color de acento", 16f, Ui.TEXT, true), Ui.lp(ctx, top = 20))
        val acScroll = HorizontalScrollView(ctx)
        acScroll.isHorizontalScrollBarEnabled = false
        accentRow = LinearLayout(ctx)
        accentRow.orientation = LinearLayout.HORIZONTAL
        accentRow.gravity = Gravity.CENTER_VERTICAL
        acScroll.addView(accentRow)
        col.addView(acScroll, Ui.lp(ctx, top = 8))

        col.addView(
            Ui.label(
                ctx,
                "Nota: los widgets de Android no pueden desenfocar el fondo ni animarse solos, " +
                    "así que el efecto vidrio es una imitación dibujada.",
                12f, Ui.SUB
            ),
            Ui.lp(ctx, top = 20)
        )

        refreshAll()
        ready = true
        return col
    }

    private fun refreshAll() {
        refreshChips()
        refreshGallery()
        refreshControls()
        renderPreviews()
    }

    // ---------- chips ----------
    private fun refreshChips() {
        chipRow.removeAllViews()
        val items = listOf(
            "all" to "Todos", WKey.SWITCH to "Switch", WKey.POWER to "Botón",
            WKey.BRIGHT to "Brillo", WKey.COLORS to "Colores"
        )
        for ((key, name) in items) {
            val b = Ui.pill(ctx, name, key == target) {
                target = key
                refreshAll()
            }
            val p = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
            p.rightMargin = dp(8)
            chipRow.addView(b, p)
        }
    }

    // ---------- vista previa ----------
    private fun renderPreviews() {
        previewBox.removeAllViews()
        for (k in WKey.ALL) {
            val w: Int
            val h: Int
            when (k) {
                WKey.SWITCH -> { w = 290; h = 72 }
                WKey.POWER -> { w = 72; h = 72 }
                WKey.BRIGHT -> { w = 290; h = 80 }
                else -> { w = 290; h = 120 }
            }
            val rv = when (k) {
                WKey.SWITCH -> WidgetViews.switchView(ctx, w, h, true)
                WKey.POWER -> WidgetViews.powerView(ctx, w, h, true)
                WKey.BRIGHT -> WidgetViews.brightnessView(ctx, w, h, true)
                else -> WidgetViews.colorView(ctx, w, h, true)
            }
            val frame = FrameLayout(ctx)
            try {
                frame.addView(rv.apply(ctx, frame))
            } catch (e: Exception) {
                val err = Ui.label(ctx, "Error: " + (e.message ?: e.toString()), 11f, 0xFFFFFFFF.toInt())
                frame.addView(err)
            }
            val lp = LinearLayout.LayoutParams(dp(w), dp(h))
            lp.topMargin = dp(10)
            lp.gravity = Gravity.CENTER_HORIZONTAL
            previewBox.addView(frame, lp)
        }
    }

    // ---------- galería ----------
    private fun refreshGallery() {
        galleryRow.removeAllViews()
        val selected = cur().theme
        for (t in Themes.ALL) {
            val look = Cfg(t.id, null, null, 100).look()
            val tile = FrameLayout(ctx)
            val isSel = t.id == selected
            val ring = GradientDrawable()
            ring.cornerRadius = dp(22).toFloat()
            ring.setColor(0x00000000)
            ring.setStroke(dp(2), if (isSel) Ui.ACCENT else 0x00000000)
            tile.background = ring

            val img = ImageView(ctx)
            img.scaleType = ImageView.ScaleType.FIT_XY
            img.setImageBitmap(Skin.card((108 * s).toInt(), (66 * s).toInt(), look, s))
            val ip = FrameLayout.LayoutParams(dp(108), dp(66))
            ip.setMargins(dp(6), dp(6), dp(6), dp(6))
            tile.addView(img, ip)

            val name = Ui.label(ctx, t.name, 12f, look.text, true)
            val np = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
            np.gravity = Gravity.BOTTOM or Gravity.START
            np.setMargins(dp(16), 0, 0, dp(14))
            tile.addView(name, np)

            val dot = View(ctx)
            val dg = GradientDrawable()
            dg.shape = GradientDrawable.OVAL
            dg.setColor(look.accent)
            dot.background = dg
            val dp2 = FrameLayout.LayoutParams(dp(12), dp(12))
            dp2.gravity = Gravity.TOP or Gravity.END
            dp2.setMargins(0, dp(16), dp(16), 0)
            tile.addView(dot, dp2)

            tile.setOnClickListener {
                Haptics.tick(ctx)
                update { c -> Cfg(t.id, null, null, c.opacity) }
                refreshGallery()
                refreshControls()
            }
            Ui.press(tile, 0.94f)
            val lp = LinearLayout.LayoutParams(dp(122), dp(80))
            lp.rightMargin = dp(6)
            galleryRow.addView(tile, lp)
            if (isSel) Ui.bounce(tile)
        }
    }

    // ---------- opacidad y colores ----------
    private fun refreshControls() {
        val c = cur()
        opacitySeek.progress = c.opacity - 20
        opacityTxt.text = "${c.opacity}%"
        fillSwatches(bgRow, BG_COLORS, c.bg, "Color de fondo") { col -> update { x -> Cfg(x.theme, col, x.accent, x.opacity) }; refreshControls() }
        fillSwatches(accentRow, ACCENT_COLORS, c.accent, "Color de acento") { col -> update { x -> Cfg(x.theme, x.bg, col, x.opacity) }; refreshControls() }
    }

    private fun fillSwatches(row: LinearLayout, colors: List<Int>, selected: Int?, title: String, onPick: (Int?) -> Unit) {
        row.removeAllViews()
        row.addView(swatch(null, selected == null) { onPick(null) })
        for (c in colors) row.addView(swatch(c, selected == c) { onPick(c) })
        val custom = TextView(ctx)
        custom.text = "＋"
        custom.textSize = 18f
        custom.gravity = Gravity.CENTER
        custom.setTextColor(Ui.TEXT)
        custom.background = Ui.rounded(ctx, Ui.CARD2, 18)
        val p = LinearLayout.LayoutParams(dp(36), dp(36))
        p.setMargins(dp(4), dp(4), dp(8), dp(4))
        custom.layoutParams = p
        custom.setOnClickListener { pickColor(title, selected ?: 0xFF888888.toInt()) { col -> onPick(col) } }
        Ui.press(custom, 0.85f)
        row.addView(custom)
    }

    private fun swatch(color: Int?, selected: Boolean, onClick: () -> Unit): View {
        val v: View
        if (color == null) {
            val t = TextView(ctx)
            t.text = "Auto"
            t.textSize = 12f
            t.gravity = Gravity.CENTER
            t.setTextColor(if (selected) 0xFF111111.toInt() else Ui.TEXT)
            t.background = Ui.rounded(ctx, if (selected) Ui.ACCENT else Ui.CARD2, 18)
            t.layoutParams = LinearLayout.LayoutParams(dp(48), dp(36)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            v = t
        } else {
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(color)
            g.setStroke(dp(if (selected) 3 else 1), if (selected) Ui.ACCENT else 0x44FFFFFF)
            v = View(ctx)
            v.background = g
            v.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        }
        v.setOnClickListener {
            Haptics.tick(ctx)
            Ui.bounce(v)
            onClick()
        }
        Ui.press(v, 0.85f)
        return v
    }

    private fun pickColor(title: String, initial: Int, onDone: (Int) -> Unit) {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val wheel = ColorWheelView(ctx)
        wheel.setColor(initial, true)
        box.addView(wheel, LinearLayout.LayoutParams(Ui.MATCH, dp(240)))
        box.addView(Ui.label(ctx, "Luminosidad", 13f, Ui.SUB), Ui.lp(ctx, top = 8))
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(initial, hsv)
        val seek = SeekBar(ctx)
        seek.max = 100
        seek.progress = (hsv[2] * 100).toInt()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { wheel.setValue(p / 100f) }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        box.addView(seek, Ui.lp(ctx, top = 2))
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Aplicar") { _, _ -> onDone(wheel.color() or 0xFF000000.toInt()) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    companion object {
        private val BG_COLORS = listOf(
            0xFFFFFFFF.toInt(), 0xFFF4F4F6.toInt(), 0xFF1C1C1E.toInt(), 0xFF000000.toInt(),
            0xFF0B1026.toInt(), 0xFF2B1B4A.toInt(), 0xFF0F3D2E.toInt(), 0xFF7A1F2B.toInt(),
            0xFF39B7E8.toInt(), 0xFFFFE3EC.toInt()
        )
        private val ACCENT_COLORS = listOf(
            0xFF34C759.toInt(), 0xFF0A84FF.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF375F.toInt(),
            0xFFBF5AF2.toInt(), 0xFF00F5FF.toInt(), 0xFFFFD60A.toInt(), 0xFFFFFFFF.toInt(),
            0xFF111111.toInt()
        )
    }
}
